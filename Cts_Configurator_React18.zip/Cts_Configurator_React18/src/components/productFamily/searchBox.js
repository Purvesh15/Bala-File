import React , {useEffect, useState} from 'react'
import {InputBase,Paper} from '@mui/material';
import ProductTreeView from './productTreeView';
// import productFamilyData from '../../assets/json/productFamily.json';
import productFamilyDataTKE from '../../assets/json/productFamily.json';
import ProductFamilyGrid from './productFamilyGrid';
import SearchTwoToneIcon from '@mui/icons-material/SearchTwoTone';
import './searchBox.css'
import { v4 as uuidv4 }  from 'uuid';

const SearchBox =(props)=>{
    const [searchValue,setSearchValue]=useState(["Categories"]);
    const [familyIdArray,setFamilyIdArray]=useState(["Categories"]);
    const [familyIdArray2,setFamilyIdArray2]=useState(["Categories"]);
    const familyIdArray1=["Categories"];
    const productData1=[];
    const [productData,setProductData]=useState(productFamilyDataTKE);
    const handleSearch=(e)=>{
        setSearchValue(e.value);
        var newArray=[];
        familyIdArray2.forEach((x)=>{
            if(x.includes(e.currentTarget.value)){
               if(!newArray.includes(x)){
                newArray.push(x);
               }
            }
        })
        setFamilyIdArray(newArray);
    }
    useEffect(()=>{
        var productData=productFamilyDataTKE;
        updateFamilyId(productData);
        setProductData(productData);
        getFamilyId(productData.children);
        setFamilyIdArray(familyIdArray1);
        setFamilyIdArray2(familyIdArray1);
    },[])
    const updateFamilyId=(nodes)=>{
        nodes.children.forEach(element => {
            if(element.id){
                element.id=uuidv4();
            }
            if(element.children && element.children.length>0){
                updateFamilyId(element);
            }
        });
    }
    const getFamilyId=(nodes)=>{
        nodes.forEach(element => {
            if(element.id){
                familyIdArray1.push(element.id);
            }
            if(element.children && element.children.length>0){
                getFamilyId(element.children);
            }
        });
    }
    // const getFamilyId=(nodes)=>{
    //     nodes.forEach(element => {
    //         if(element.id){
    //             familyIdArray1.push(element.id);
    //         }
    //         if(element.children && element.children.length>0){
    //             getFamilyId(element.children);
    //         }
    //     });
    // }
    const handleChangeSearch=(nodes)=>{
        nodes.forEach(element => {
            if(element.id){
                familyIdArray1.push(element.id);
            }
            if(element.children && element.children.length>0){
                getFamilyId(element.children);
            }
        });
    }
    
    return (
       <>
       {/* <Paper
        id="productFamilySearch"
        component="form"
        sx={{ display: 'flex', alignItems: 'center', width: 500,padding:'0px 10px 2px 0px' ,height:30}}
        >
        
        <SearchTwoToneIcon style={{width:45,height:34,background:"#1976d2"}}></SearchTwoToneIcon>
        <InputBase
            sx={{ ml: 1, flex: 1 ,fontSize:"12px"}}
            placeholder="Search by Product,id,etc."
            inputProps={{ 'aria-label': 'search id' }}
            onChange={(e)=>{handleSearch(e)}}
        />
        </Paper> */}
        <div style={{display:"flex"}}>
            <div className='familyPaddingTree'>
            <ProductTreeView  
                defaultValue={searchValue}
                familyIdArray={familyIdArray}
                productData={productData}
            ></ProductTreeView></div>
          <div style={{width:"100%"}} className='familyPadding'>
          <ProductFamilyGrid 
          ></ProductFamilyGrid></div>
        </div>
       
       
       </>
    )

}
export default SearchBox;