import React, { useEffect, useState}  from 'react';
import {useDispatch,useSelector} from 'react-redux';
import { useNavigate } from 'react-router-dom';
import {Card, Grid, CardActionArea, CardContent, Typography, CardMedia } from '@mui/material'
import './productFamilyGrid.css';
// import productFamilyData from  '../../assets/json/productFamily.json';
import productFamilyData from  '../../assets/json/productFamily.json';

import ArrowRightIcon from '@mui/icons-material/ArrowRight';
import './productFamilyGrid.css';
import { changeNavigation ,setCurrentFamily,setNavFamily} from '../../actions/appAction';
import NavigationBar from '../../views/navigation/navigationBar';
export default function Layout() {
    const dispatch =useDispatch()
    const navigate=useNavigate();
    const app = useSelector(state => state.app);
    const [productGridData,setProductData]=useState([]);
    const [navigateFamilyArray,setNavigation]=useState([]);
    useEffect(()=>{
        if(productFamilyData && app.currentFamily==null){
            var familyArray=[];
            productFamilyData.children.forEach((family)=>{
                familyArray.push(family);
            });
            setProductData(familyArray);
            dispatch(setNavFamily([]));
        };
        if(app.currentFamily!==null){
            var data= getFamilyById(productFamilyData.children,app.currentFamily);
            setProductData(familyArray);
            //redirectCurrentFamily(data,productFamilyData)
            dispatch(setCurrentFamily(null));
        }
    },[])
    useEffect(()=>{
        if(app.currentFamily!==null){
            var familyArray=[];
            productFamilyData.children.forEach((family)=>{
                familyArray.push(family);
            });
            var data= getFamilyById(productFamilyData.children,app.currentFamily);
            setProductData(familyArray);
            //redirectCurrentFamily(data,productFamilyData)
            handleClickFamily(app.currentFamily,false)
            //dispatch(setCurrentFamily(null));
        }
    },[app.currentFamily])
    function getFamilyById(data, id) {
        for (const item of data) {
          if (item.name === id) return item;
          if (item.children?.length) {
            const children = getFamilyById(item.children, id);
            if (children) return children;
          }
        }
    }
    const redirectCurrentFamily=(currentFamily)=>{
        var familyArray=[];
        var newNavigateFamilyArray=[];
        var newArray=[];
        var check=false;
        app.navFamily.forEach((family)=>{
            var data= getFamilyById(productFamilyData.children,family);
            newNavigateFamilyArray.push(data);
        });
        if(currentFamily.children && currentFamily.children.length>0){
            currentFamily.children.forEach((family)=>{
                familyArray.push(family);
            })
        }
        setProductData(familyArray);
        setNavigation(newNavigateFamilyArray);
        var familyKeys=[];
        newNavigateFamilyArray.forEach((family)=>{
            familyKeys.push(family.name);
        });
        dispatch(setNavFamily(familyKeys));
    }
    const handleClickFamily=(currentFamily,flag)=>{
        var familyArray=[];
        var newNavigateFamilyArray=navigateFamilyArray;
        if(flag){
            newNavigateFamilyArray.push(currentFamily);
        }
        else{
            var newArray=[];
            var check=false;
            newNavigateFamilyArray.forEach((family)=>{
                if(!check && family.id !=currentFamily.id){
                    newArray.push(family);
                }
                else if(!check){
                    newArray.push(family);
                    check=true;
                }
            })
            newNavigateFamilyArray=newArray;
        }
        // if(currentFamily?.children && currentFamily?.children.length>0){
        //     currentFamily?.children.map((family)=>{
        //         familyArray.push(family);
        //     })
        // }
        setProductData(familyArray);
        setNavigation(newNavigateFamilyArray);
        var familyKeys=[];
        navigateFamilyArray.forEach((family)=>{
            familyKeys.push(family.name);
        })
        dispatch(setNavFamily(familyKeys));
        if(familyArray.length===0){
            if(currentFamily.name!=undefined){
                dispatch(setCurrentFamily(currentFamily.name));
            }
            else{
                dispatch(setCurrentFamily(currentFamily));
            }
            //familyKeys.push("XYZ6458DGET")
            dispatch(setNavFamily(familyKeys));
            dispatch(changeNavigation(1));
            navigate('/configure')
        }
    }
    const getFamily=(currentFamily,allFamily)=>{
        allFamily.children.forEach((family)=>{
            if(family.id==currentFamily.id){
                handleClickFamily(family,false);
            }
            else if(family.children && family.children.length>0){
                getFamily(currentFamily,family )
            }
        })
    }
    return (
        <div >
            {/* <div className={navigateFamilyArray && navigateFamilyArray.length>0?'familyGridHeader':''} >
                {navigateFamilyArray.map((item,index)=>{
                    var checkArrow=false
                    if(navigateFamilyArray.length>1 && navigateFamilyArray.length!=index+1){
                        checkArrow=true
                    }
                    return <div className='flex' onClick={()=>getFamily(item,productFamilyData)}>{item.name} {checkArrow && <ArrowRightIcon style={{width:"20px",color:"#1976d2"}}></ArrowRightIcon> }</div>
                })}
            </div> */}
            <Grid container spacing={2} style={{marginTop:"1px"}}> 
            {productGridData.length>0 && 
                productGridData.map((family)=>{
                   return(
                    <Grid item xs={2} onClick={()=> handleClickFamily(family,true)} style={{minWidth:"140px"}} >
                        <Card >
                            <CardActionArea >
                                <CardMedia 
                                component="img"
                                height="140"
                                image={family.image}
                                />
                                <CardContent>
                                    <Typography sx={{fontSize:"12px"}} align="center" gutterBottom variant="body2" component="div" >
                                      {family.name}
                                    </Typography>
                                    <Typography sx={{fontSize:"12px"}} align="center" variant="body2" color="text.secondary">
                                      {family.ShortDescription}
                                    </Typography>
                                </CardContent>
                            </CardActionArea>
                        </Card>
                    </Grid> )

                })
            }
            </Grid> 
            {productGridData.length===0 &&
                <Typography style={{marginTop:"10%"}} align="center"  component="div" >
                 No Products.Please go back.
                </Typography>
            }
        </div>
    );
}
