import React, {useEffect, useState} from 'react';
import productSelector from '../../assets/json/productSelector.json';
import { addToCartItem, changeNavigation } from '../../actions/appAction';
import {useDispatch,useSelector} from 'react-redux';
import BuildIcon from '@mui/icons-material/Build';
import {TextField,Box,List,ListItem, ListItemButton,ListItemText,Paper, Divider, FormControl, OutlinedInput} from '@mui/material';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExportToExcel from './exportExcel';
import ExportToPdf from './exportPdf';
import DeleteIcon from '@mui/icons-material/Delete';
import Images from '../../assets/js/asset';

const CartTable=()=>{
    const dispatch=useDispatch();
    const app =useSelector(state=>state.app);
    const [selector,setSelector]=useState([]);
    const [isGridView,setView]=useState(true);
    const [isProductPage,setProductPage]=useState(true);
    const salesArea=useSelector(state=>state.app.salesArea)
    
    useEffect(()=>{
        setSelector(productSelector);
    });
    const handleClickConfigure=(product)=>{
        setProductPage(false);
    }
    const addToCart=()=>{
        dispatch(changeNavigation(2));
    }
    const clickExpand=(currentProduct)=>{
        var newCartItems=JSON.parse(JSON.stringify(app.cartItems));
        newCartItems.forEach((cartItem)=>{
          if(cartItem.id ==currentProduct.id){
            if(cartItem.isShowChildren){
               cartItem.isShowChildren=false;
            }
            else{
               cartItem.isShowChildren=true;
            }
          }
        });
        dispatch(addToCartItem(newCartItems));
    }
    const clickCollapse=(currentProduct)=>{
        var newCartItems=JSON.parse(JSON.stringify(app.cartItems));
        newCartItems.forEach((cartItem)=>{
          if(cartItem.id ==currentProduct.id){
            if(cartItem.isShowChildren){
                cartItem.isShowChildren=false;
            }
            else{
                cartItem.isShowChildren=true;
            }
          }
        });
        dispatch(addToCartItem(newCartItems));
    }
    const changeProductQuantity=(e,productId,accessoryId,type)=>{
        var newCartItems=JSON.parse(JSON.stringify(app.cartItems));
        newCartItems.forEach((cartItem)=>{
            if(cartItem.guid===productId){
                if(type=="product"){
                    if(e.target.value!=""){
                        cartItem.stock=parseInt(e.target.value );
                        if(cartItem.unitPrice==undefined){
                            cartItem.unitPrice= cartItem.Price;
                            cartItem.price= (cartItem.price*parseInt(e.target.value )).toFixed(2);
                        }
                        else{
                            cartItem.price= (cartItem.unitPrice*parseInt(e.target.value )).toFixed(2);
                        }
                    }
                    else{
                        cartItem.stock=0;
                        if(cartItem.unitPrice==undefined){
                            cartItem.unitPrice= cartItem.price;
                        }
                        cartItem.price=0;
                    }
                }
                else if(type=="accessory"){
                    cartItem.children.forEach((accessory)=>{
                      if(accessory.guid==accessoryId){
                        if(e.target.value!=""){
                            cartItem.orderQuantity=parseInt(e.target.value );
                            if(cartItem.unitPrice==undefined){
                                cartItem.unitPrice= cartItem.Price
                                cartItem.Price= (cartItem.Price*parseInt(e.target.value )).toFixed(2);
                            }
                            else{
                                cartItem.Price= (cartItem.unitPrice*parseInt(e.target.value )).toFixed(2);
                            }
                        }
                        else{
                            cartItem.orderQuantity=0;
                            if(cartItem.unitPrice==undefined){
                                cartItem.unitPrice= cartItem.Price
                            }
                            cartItem.Price=0;
                        }
                      }
                    })
                }
            }
        });
        dispatch(addToCartItem(newCartItems));
    }
    const deleteCartItem=(e,productId,accessoryId,type,deleteIndex)=>{
        var newCartItems=JSON.parse(JSON.stringify(app.cartItems));
        var updateCarItems=[];
        newCartItems.forEach((cartItem,index)=>{
            if(cartItem.guid===productId){
                if(type=="product"){
                    newCartItems.splice(index, 1);
                }
                else if(type=="accessory"){
                    cartItem.children.forEach((accessory,accIndex)=>{
                      if(accessory.guid==accessoryId){
                        cartItem.children.splice(accIndex, 1);
                      }
                    })
                }
            }
        });
        dispatch(addToCartItem(newCartItems));
    }
    return (
        <>  
            <Box sx={{ width: '-webkit-fill-available',overflow:"hidden"}}>
            <Box sx={{fontSize:"12px",textAlign:"center", display:"flex",paddingTop:"10px",color:"darkblue",fontWeight:500}}>
                <div style={{flexBasis:"7%"}}>S.No</div>
                <div style={{flexBasis:"9%"}}>Image</div>
                <div style={{flexBasis:"17%"}}>Product Id</div>
                <div style={{flexBasis:"29%"}}>Description</div>
                <div style={{flexBasis:"12%"}}>Unit Price</div>
                <div style={{flexBasis:"12%"}}>Quantity</div>
                <div style={{flexBasis:"16%"}}>Net Price</div>
                <div style={{flexBasis:"10%"}}></div>
            </Box>
            <Divider sx={{paddingTop:"10px",color:"darkblue"}}/>
            <Box sx={{height:"50vh",overflow:"auto",overflowX:"hidden"}}>
            {app.cartItems.map((product,index)=>{
                return (
                <><Box sx={{textAlign:"center",display:"flex",paddingTop:"5px",height:"35px"}}>
                    <div style={{alignSelf:"center",fontSize:"11px",flexBasis:"7%"}}>{index+1}.</div>
                    <div style={{alignSelf:"center", display:"flex",fontSize:"11px",flexBasis:"9%"}}>
                        {product.isShowChildren && <div style={{cursor:"pointer"}}><ExpandLessIcon onClick={()=>clickExpand(product)}></ExpandLessIcon ></div>}
                        {!product.isShowChildren && <div style={{cursor:"pointer"}}><ExpandMoreIcon onClick={()=>clickCollapse(product)}></ExpandMoreIcon></div>}
                        <img width={30} src={product.thumbnail ?product.thumbnail:Images[product.image]}></img></div>
                    <div style={{alignSelf:"center", fontSize:"11px",flexBasis:"12%"}}>{product.brand}</div>
                    <div style={{alignSelf:"center",fontSize:"11px",flexBasis:"28%"}}>{product.description}</div>
                    <div style={{alignSelf:"center",fontSize:"11px",flexBasis:"14%"}}>{salesArea.currency +" "+product.price}</div>
                    {/* <TextField   size="small"   sx={{flexBasis:"18%", width:"20px",maxHeight:"5px"}} id="outlined-quantity" label="" variant="outlined" /> */}
                        {/* <FormControl sx={{textAlign:"center !important"}} >
                            <OutlinedInput onChange={(e)=>changeProductQuantity(e,product.guid,"","product")} value={product.stock}  sx={{fontSize:"12px",width:'80px !important',height:"30px",textAlign:"center !important"}} />
                        </FormControl> */}
                        <FormControl sx={{alignSelf:"center",flexBasis:"8%", width: '3ch',padding:"5px"}}>
                           <OutlinedInput onChange={(e)=>changeProductQuantity(e,product.guid,"","product")} value={product.stock} sx={{fontSize:"12px",textAlign:"center",height:"30px",textAlignLast:"center !important"}} />
                        </FormControl>
                    <div style={{alignSelf:"center", fontSize:"11px",flexBasis:"15%"}}>{salesArea.currency +" "+product.price}</div>
                    <DeleteIcon style={{alignSelf:"center",flexBasis:"5%",cursor:"pointer"}}onClick={(e)=>deleteCartItem(e,product.guid,"","product",index)}></DeleteIcon>
                    <BuildIcon  style={{alignSelf:"center",flexBasis:"5%",cursor:"pointer"}}onClick={(e)=>handleClickConfigure(e)}></BuildIcon>
                </Box>
                <Divider sx={{paddingTop:"3px",color:"darkblue"}}/>
                {product.isShowChildren && product.children && product.children.length>0 && product.children.map((accessory,index)=>{
                    return(
                        <>
                        <Box sx={{textAlign:"center", display:"flex",paddingTop:"5px",height:"35px",transition:"height 600ms" }}>
                            <div style={{fontSize:"11px",flexBasis:"8%"}}></div>
                            <div style={{fontSize:"11px",flexBasis:"9%"}}><img width={30} src={accessory.image}></img></div>
                            <div style={{fontSize:"11px",flexBasis:"15%"}}>{accessory.id}</div>
                            <div style={{fontSize:"11px",flexBasis:"20%"}}>{accessory.shortDescrtiption}</div>
                            <div style={{fontSize:"11px",flexBasis:"18%"}}>{salesArea.currency +" "+accessory.Price}</div>
                            {/* <TextField   size="small" sx={{flexBasis:"10%", width:"20px",maxHeight:"5px"}} id="outlined-quantity" label="" variant="outlined" /> */}
                                <FormControl sx={{flexBasis:"12%"}}>
                                    <OutlinedInput onChange={(e)=>changeProductQuantity(e,product.guid,accessory.guid,"accessory")} value={accessory.orderQuantity}  sx={{fontSize:"11px",width:'80px !important',height:"30px",textAlign:"center !important"}}/>
                                </FormControl>
                            <div style={{fontSize:"11px",flexBasis:"8%"}}>{salesArea.currency +" "+ accessory.Price}</div>
                            <DeleteIcon style={{alignSelf:"center",flexBasis:"5%",cursor:"pointer"}}onClick={(e)=>deleteCartItem(e,product.guid,accessory.guid,"accessory",index)}></DeleteIcon>
                            <div style={{alignSelf:"center",fontSize:"11px",flexBasis:"5%"}}></div>
                        </Box>
                        <Divider sx={{paddingTop:"3px",color:"darkblue"}}/>
                        </>
                    )
                    })
                    }
                </>
            )})
        }
        </Box>
        </Box>
        </>
    )
}
export default CartTable;