import React from "react"
import { useState } from "react";
import { useSelector } from "react-redux";
import jsPDF from 'jspdf'
import { useEffect } from "react";
import { Button } from "@mui/material";
import autoTable from 'jspdf-autotable';
import Images from "../../assets/js/asset";
import userData from '../../assets/json/user.json'
const columnsData=["S.No","Product Name","Description","Unit Price","Quantity","Net Price"];

const SingleReport=()=>{
    const app=useSelector(state=>state.app);
    const[columns,setColumn]=useState([]);
    const[rows,setRows]=useState(null);
    const productConfigurations=useSelector(state=>state.app.productConfigurations)
    const accessoryConfigurations=useSelector(state=>state.app.accessoryConfigurations)

    useEffect(()=>{
        var columns=[];
        var allRows=[];
        columnsData.forEach((column)=>{
            columns.push(column);
        });
        var styles=[{ content: 'Text', colSpan: 2, rowSpan: 2, styles: { halign: 'center' } }]
        var sNo=1;
        app.cartItems.forEach((cartItem,index)=>{
           var rows=[];
           rows.push((sNo).toString())
           rows.push(cartItem.brand)
           rows.push(cartItem.description)
           rows.push(cartItem.price.toString())
           rows.push(cartItem.stock.toString())
           rows.push(cartItem.price.toString())
           sNo++;
           //rows.push(row6)
           allRows.push(rows);
           if(cartItem.children){
            cartItem.children.forEach((childCart,childIindex)=>{
                var rows=[];
                rows.push((sNo).toString())
                rows.push(childCart.id)
                rows.push(childCart.shortDescrtiption)
                rows.push(childCart.Price.toString())
                rows.push(childCart.orderQuantity.toString())
                rows.push(childCart.Price.toString())
                //rows.push(row6)
                allRows.push(rows);
                sNo++;
            });
           }
        });
        setRows(allRows);
        setColumn(columns)
    },[]);
    const generateReport=()=>{
        const doc = new jsPDF()
        var logoImage = new Image();
        var src = Images.CTSLogo;
        logoImage.src = src;
        doc.setDrawColor(0, 0, 72);
        doc.setFillColor(0, 0, 72);
        doc.rect(0, 0.5, 250, 5, 'FD'); //Fill and Border
        doc.setDrawColor(0, 0, 72);
        doc.setFillColor(0, 0, 72);
        doc.rect(0, 6, 250, 1, 'FD'); //Fill and Border
        doc.addImage(Images.CTSLogo, "png", 75, 10, 50,15);

        doc.setFontSize(12);
        doc.setTextColor(0,0,72);
        doc.text('CTS CONFIGURATOR REPORT',70, 30);

        doc.setDrawColor(0, 0, 72);
        doc.setFillColor(255);
        doc.rect(2, 35, 193, 40, 'FD'); //Fill and Border
       
        doc.setFontSize(7);
        doc.setTextColor(0, 0, 72);
        var QuoteDetails=userData["Owner"];
        var x=5;
        var y=42;
        Object.keys(QuoteDetails).forEach((key,index)=>{
            doc.text(key,5, y);
            doc.text("--",35, y);
            doc.text(QuoteDetails[key],40, y);
             y+=6;
        });
        doc.setFontSize(12);
        doc.setTextColor(0,0,72);
        doc.text('Client Information',2, y+10);
        y+=5;

        doc.setDrawColor(0, 0, 72);
        doc.setFillColor(255);
        doc.rect(2, y+10, 193, 40, 'FD'); //Fill and Border
        y+=15;
        doc.setFontSize(7);
        doc.setTextColor(0, 0, 72);
        var QuoteDetails=userData["Client"];
        Object.keys(QuoteDetails).forEach((key,index)=>{
            doc.text(key,5, y);
            doc.text("--",35, y);
            doc.text(QuoteDetails[key],40, y);
             y+=6;
        });

        y+=15;
        doc.autoTable({
            body: rows,
            startX: 1,
            startY: y,
            margin:3,
            head:[columns],
            foot:[[' ',' ', ' ',' ','Total Price', '1000', '  ']],
            headStyles :{fontSize:8,halign: 'center',fillColor : [0, 0, 72],textColor: [255, 255, 255],},
            footStyles :{fontSize:8,halign: 'center',fillColor : [0, 0, 72],textColor: [255, 255, 255],},
            theme: 'grid',
            columnStyles: {
                0: {fontSize:8,halign: 'center', cellWidth: 12,},
                1: {fontSize:8,halign: 'center', cellWidth: 30,},
                2: {fontSize:8,halign: 'center', cellWidth: 70,},
                3: {fontSize:8,halign: 'center', cellWidth: 25,},
                4: {fontSize:8,halign: 'center', cellWidth: 25,},
                5: {fontSize:8,halign: 'center', cellWidth: 30,}
            }
		})
        y+=((rows.length+1)*5)+15;

        doc.setFontSize(10);
        doc.setTextColor(0,0,72);
        doc.text('If u accept this quote kindly sign here and return:   (Signature) ',10, y+30);

        doc.setFontSize(10);
        doc.setTextColor(0,0,72);
        doc.text('THANK YOU FOR YOUR BUSINESS',50,280);

        doc.save('CTS_Configurator.pdf')
    }
    // const getReportPdf=()=>{
    //     imageToBase64(Images.CTSLogo) // Path to the image
    //     .then(
    //         (response) => {
    //             console.log(response);
    //             var image="data:image/png;base64,"+response;
    //             generateReport(image) // "cGF0aC90by9maWxlLmpwZw=="
    //         }
    //     )
    //     .catch(
    //         (error) => {
    //             console.log(error); // Logs an error if there was one
    //         }
    //     )
    // }
    return(
        <>
        <div style={{padding:"2px"}}>
             <Button onClick={()=>generateReport()} sx={{fontSize:"12px",backgroundColor:"#000048",padding:"6px",color:"white",height:"30px"}}>Report</Button>
        </div>
        </>
    )
}
export default SingleReport;