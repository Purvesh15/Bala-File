
import { useSelect } from '@mui/base';
import { Button } from '@mui/material';
import React, {Component, useEffect, useState} from 'react';
import ReactExport from 'react-export-excel-xlsx-fix';
import { useSelector } from 'react-redux';
const ExcelFile = ReactExport.ExcelFile;
const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;

const columnsData=["S.No","Product Id","Description","Unit Price","Quantity","Net Price"]
const ExportToExcel=(props)=>{

    const app=useSelector(state=>state.app);
    const[columns,setColumn]=useState([]);
    const[datasheet,setDataSheet]=useState(null);
    useEffect(()=>{
        var columns=[];
        var allRows=[];
        columnsData.forEach((column)=>{
            var obj={
                value:column,
                widthPx: 160,
                style: { font: { sz: "20", bold: true } },
            }
            columns.push(obj);
        });

        app.cartItems.forEach((cartItem,index)=>{

           var row0={
            value:(index+1).toString(), style: { font: { sz: "24", bold: false } } 
           }
           var row1={
            value:cartItem.brand.toString(), style: { font: { sz: "24", bold: false } } 
           }
           var row2={
            value:cartItem.description.toString(), style: { font: { sz: "24", bold: false } } 
           }
           var row3={
            value:cartItem.price.toString(), style: { font: { sz: "24", bold: false } } 
           }
           var row4={
            value:cartItem.stock.toString(), style: { font: { sz: "24", bold: false } } 
           }
           var row5={
            value:cartItem.price.toString(), style: { font: { sz: "24", bold: false } } 
           }
           var rows=[];
           rows.push(row0)
           rows.push(row1)
           rows.push(row2)
           rows.push(row3)
           rows.push(row4)
           rows.push(row5)
           //rows.push(row6)
           allRows.push(rows);           
        });
        var dataSet=[{
            columns:columns,
            data:allRows
        }]
        setDataSheet(dataSet);
    },[])
    return(
        <div style={{padding:"2px"}}>
            <ExcelFile filename="CTS_Configurator" element={<Button sx={{fontSize:"12px",backgroundColor:"#000048",color:"white",height:"30px"}}>Export Excel</Button>}>
                <ExcelSheet dataSet={datasheet} name="CTS_COnfigurator"/>
            </ExcelFile>
        </div>
    )
}
export default ExportToExcel;