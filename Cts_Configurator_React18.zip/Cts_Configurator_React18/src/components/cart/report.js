import React from "react"
import { useState } from "react";
import { useSelector } from "react-redux";
import jsPDF from 'jspdf'
import { useEffect } from "react";
import { Button } from "@mui/material";
import autoTable from 'jspdf-autotable';
import Images from "../../assets/js/asset";
import userData from '../../assets/json/user.json'
const columnsData=["S.No","Product Name","Description","Unit Price","Quantity","Net Price"];

const Report=()=>{
    const app=useSelector(state=>state.app);
    const[columns,setColumn]=useState([]);
    const[rows,setRows]=useState(null);
    const productConfigurations=useSelector(state=>state.app.productConfigurations)
    const accessoryConfigurations=useSelector(state=>state.app.accessoryConfigurations)

    useEffect(()=>{
        var columns=[];
        var allRows=[];
        columnsData.forEach((column)=>{
            columns.push(column);
        });

        app.cartItems.forEach((cartItem,index)=>{
           var rows=[];
           rows.push((index+1).toString())
           rows.push(cartItem.brand)
           rows.push(cartItem.description)
           rows.push(cartItem.price.toString())
           rows.push(cartItem.stock.toString())
           rows.push(cartItem.price.toString())
           //rows.push(row6)
           allRows.push(rows);           
        });
        setRows(allRows);
        setColumn(columns)
    },[]);
    const generateReport=()=>{
        const doc = new jsPDF()
        var logoImage = new Image();
        var src = Images.CTSLogo;
        logoImage.src = src;
        //coverImage
        doc.addImage(Images.CTSLogo, "png", 150, 10, 50,15);
        //coverImage
        doc.setDrawColor(255);
        doc.setFillColor(0, 0, 72);
        doc.rect(5, 40, 200, 10, 'FD'); //Fill and Border
        doc.setFontSize(12);
        doc.setTextColor(255);
        doc.text('CTS CONFIGURATOR REPORT',10, 47);
        doc.addImage(Images.coverImage, "png", 5, 60,200,150);
        // It can parse html:
        // <table id="my-table"><!-- ... --></table>
        doc.addPage();
        doc.addImage(Images.CTSLogo, "png", 150, 10, 40,10);
        var x=10;
        var y=50;
        doc.setDrawColor(255);
        doc.setFillColor(0, 0, 72);
        doc.rect(5, 30, 200, 10, 'FD'); //Fill and Border
        doc.setFontSize(12);
        doc.setTextColor(255);
        doc.text('USER DETAILS',10, 37);
        doc.setDrawColor(0, 0, 72);
        doc.rect(5, 45, 200, 220);
        doc.setFillColor(0);
        var data=userData["User"];
        Object.keys(data).forEach((key,index)=>{
            doc.setTextColor(0, 0, 72);
            doc.text(key,12, y);
            doc.text("--",50, y);
            doc.text(data[key],55, y);
             y+=10;
        });
        var data1=userData["Quote"];
        Object.keys(data1).forEach((key1,index)=>{
            doc.setTextColor(0, 0, 72);
            doc.text(key1,12, y);
            doc.text("--",50, y);
            doc.text(data1[key1],55, y);
             y+=10;
        });
        // <table id="my-table"><!-- ... --></table>
        doc.addPage();
        doc.addImage(Images.CTSLogo, "png", 150, 10, 40,10);
        doc.setDrawColor(255);
        doc.setFillColor(0, 0, 72);
        doc.rect(5, 30, 200, 10, 'FD'); //Fill and Border
        doc.setFontSize(12);
        doc.setTextColor(255);
        doc.text('PRODUCT CART',10, 37);
        doc.autoTable({
            body: rows,
            startX: 5,
            startY: 50,
            head:[columns],
            foot:[[' ',' ', ' ',' ','Total Price', '1000', '  ']],
            headStyles :{halign: 'center',fillColor : [0, 0, 72],textColor: [255, 255, 255],},
            footStyles :{halign: 'center',fillColor : [0, 0, 72],textColor: [255, 255, 255],},      
            theme: 'grid',
            columnStyles: {
                0: {halign: 'center', cellWidth: 12,},
                1: {halign: 'center', cellWidth: 30,},
                2: {halign: 'center', cellWidth: 70,},
                3: {halign: 'center', cellWidth: 25,},
                4: {halign: 'center', cellWidth: 25,},
                5: {halign: 'center', cellWidth: 30,}
            },
		})
        
        doc.addPage();
        doc.addImage(Images.CTSLogo, "png", 150, 10, 40,10);
        doc.setDrawColor(255);
        doc.setFillColor(0, 0, 72);
        doc.rect(5, 30, 200, 10, 'FD'); //Fill and Border
        doc.setFontSize(12);
        doc.setTextColor(255);
        doc.text('CONFIGURATION DETAILS',10, 37);
        y=60
        doc.setDrawColor(0, 0, 72);
        doc.rect(5, 50, 200, 220);
        doc.setFillColor(0);
        productConfigurations.forEach((config)=>{
            doc.setTextColor(0, 0, 72);
            doc.text(config.name,12, y);
            doc.text("--",50, y);
            var value=config.selectedValue!=""?config.selectedValue.toString():"NA"
            doc.text(value,58, y);
            y+=10;
        });
        accessoryConfigurations.forEach((accConfig)=>{
            doc.setFontSize(15);
            doc.setTextColor(0, 0, 72);
            doc.text(accConfig.name,12, y);
            y+=10;

            if(y>250){
             doc.addPage();
             y=20; 
             doc.setDrawColor(0, 0, 72);
             doc.rect(5, 10, 200, 220);
             doc.setFillColor(0);  
            }
            doc.setFontSize(12);
            accConfig.configuration.forEach((config)=>{
                if(y>250){
                    doc.addPage(); 
                    y=20; 
                    doc.setDrawColor(0, 0, 72);
                    doc.rect(5, 10, 200, 250);
                    doc.setFillColor(0);   
                }
                doc.text(config.name,14, y);
                doc.text("--",50, y);
                var value=config.selectedValue!=""?config.selectedValue.toString():"NA"
                doc.text(value,58, y);
                y+=10;
            })
            
            y+=10;
        });
        // Object.keys(productConfigurations).forEach((key,index)=>{
        //     doc.setTextColor(0, 0, 72);
        //     doc.text(key,12, y);
        //     doc.text("--",50, y);
        //     doc.text(productConfigurations[key],55, y);
        //      y+=10;
        // });
        

        doc.addPage();
        doc.addImage(Images.CTSLogo, "png", 150, 10, 40,10);
        doc.setDrawColor(255);
        doc.setFillColor(0, 0, 72);
        doc.rect(5, 30, 200, 10, 'FD'); //Fill and Border
        doc.setFontSize(12);
        doc.setTextColor(255);
        doc.text('CONTACT US',10, 37);
        doc.setTextColor(0, 0, 72);
        doc.text('\n Chennai Cognizant Kits Campus \n Software Development Block (SDB)-3 \n 03rd floor to 06th floor \n Survey No. 602/3,Plot No. 1\n ELCOT IT/ ITES-SEZ\n Sholinganallur \n Kanchipuram District \n Chennai 600 119\n Tamil Nadu \n Tel: 1800 208 6999 \n Email: inquiry@cognizant.com',12, 45)
        doc.addImage(Images.CTSLogo, "png", 10, 100, 60,15);
        doc.save('CTS_Configurator.pdf')
    }
    // const getReportPdf=()=>{
    //     imageToBase64(Images.CTSLogo) // Path to the image
    //     .then(
    //         (response) => {
    //             console.log(response);
    //             var image="data:image/png;base64,"+response;
    //             generateReport(image) // "cGF0aC90by9maWxlLmpwZw=="
    //         }
    //     )
    //     .catch(
    //         (error) => {
    //             console.log(error); // Logs an error if there was one
    //         }
    //     )
    // }
    return(
        <>
        <div style={{padding:"2px"}}>
             <Button onClick={()=>generateReport()} sx={{fontSize:"12px",backgroundColor:"#000048",padding:"6px",color:"white",height:"30px"}}>Report</Button>
        </div>
        </>
    )
}
export default Report;