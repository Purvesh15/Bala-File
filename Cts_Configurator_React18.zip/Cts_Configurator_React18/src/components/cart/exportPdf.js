
import { useSelect } from '@mui/base';
import { Button } from '@mui/material';
import React, {Component, useEffect, useState} from 'react';
import ReactExport from 'react-export-excel-xlsx-fix';
import { useSelector } from 'react-redux';
import jsPDF from 'jspdf'
import autoTable from 'jspdf-autotable'
const ExcelFile = ReactExport.ExcelFile;
const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;

const columnsData=["S.No","Product Name","Description","Unit Price","Quantity","Net Price"]
const ExportToPdf=(props)=>{
    const app=useSelector(state=>state.app);
    const[columns,setColumn]=useState([]);
    const[rows,setRows]=useState(null);
    useEffect(()=>{
        var columns=[];
        var allRows=[];
        columnsData.forEach((column)=>{
            columns.push(column);
        });

        app.cartItems.forEach((cartItem,index)=>{
           var rows=[];
           rows.push((index+1).toString())
           rows.push(cartItem.brand)
           rows.push(cartItem.description)
           rows.push(cartItem.price.toString())
           rows.push(cartItem.stock.toString())
           rows.push(cartItem.price.toString())
           //rows.push(row6)
           allRows.push(rows);           
        });
        setRows(allRows);
        setColumn(columns)
    },[]);
    const exportToPdf=()=>{
        const doc = new jsPDF()
        doc.text('CTS Configurator BOM',75, 10);
        // It can parse html:
        // <table id="my-table"><!-- ... --></table>
        doc.autoTable({
            body: rows,
            startY: 20,
            startX: 10,
            head:[columns],
            foot:[[' ',' ', ' ',' ','Total Price', '1000', '  ']],
            headStyles :{halign: 'center',fillColor : [0, 0, 72],textColor: [255, 255, 255],},
            footStyles :{halign: 'center',fillColor : [0, 0, 72],textColor: [255, 255, 255],},      
            theme: 'grid',
            columnStyles: {
                0: {halign: 'center', cellWidth: 12,},
                1: {halign: 'center', cellWidth: 30,},
                2: {halign: 'center', cellWidth: 70,},
                3: {halign: 'center', cellWidth: 25,},
                4: {halign: 'center', cellWidth: 25,},
                5: {halign: 'center', cellWidth: 30,}
            },
		})
        // autoTable(doc, 
        //     {   
        //         html: '#my-table' ,
        //         body: [
        //             [{ content: 'Text', colSpan: 2, rowSpan: 2, styles: { halign: 'center' ,minCellWidth:10} }],
        //         ],
        //     })
        
        // // Or use javascript directly:
        // autoTable(doc, {
        //   head: [columns],
        //   body: [rows],
        // })
        
        doc.save('CTS_Configurator.pdf')
    }
    return(
        <div style={{padding:"2px"}}>
           <Button sx={{fontSize:"12px",backgroundColor:"#000048",color:"white",height:"30px"}} onClick={()=>exportToPdf()}>EXPORT PDF</Button>
          
        </div>
    )
}
export default ExportToPdf;