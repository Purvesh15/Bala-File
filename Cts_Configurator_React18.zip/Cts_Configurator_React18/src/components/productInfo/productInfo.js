import React, { useEffect, useState } from 'react';
import { TabContext, TabPanel } from "@mui/lab";
import { Button, CardMedia, Dialog, DialogContent, DialogContentText, DialogTitle, Divider, Grid, Tab, Tabs, Typography } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { display } from '@mui/system';
import { setProductInfo } from '../../actions/appAction';

const ProductInfo=(props)=>{
    const dispatch=useDispatch();
    const [value,setValue]=useState(0);
    const [productInfo, setProductInformation] = useState([]);
    const [open,setOpen]=useState(false);
    const [selectedImage,setImage]=useState();
    const app=useSelector(state=>state.app);
    useEffect(()=>{
        if(app.productInfo!=null){
            setProductInformation(app.productInfo);
            setOpen(true);
            setValue(0);
            setImage(app.productInfo.thumbnail)
        }
    },[app.productInfo]);
    const handleTabs=(val)=>{
        setValue(val);
    }  
    const handleClose = () => {
        setOpen(false);
        dispatch(setProductInfo(null));
    };
    const changeImage=(image)=>{
        setImage(image)
    }
    return(
    <div >
        <Dialog
            open={open}
            onClose={()=>handleClose()}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            maxWidth={'lg'}
            sx={{background:"#f1f3f6"}}
        >
            <div>
                <DialogTitle  sx={{fontSize:"12px",color:"#000058",display:"flex"}} id="alert-dialog-title">
                     < Typography style={{flexBasis:"90%",alignItems:"center"}}>{productInfo.description}</Typography>
                     <Button style={{flexBasis:"10%",alignItems:"center"}} onClick={()=>handleClose()} autoFocus>
                        <p>Close</p>
                    </Button>
                </DialogTitle>
                
                <DialogContent  sx={{fontSize:"12px",display:"flex"}}>
                    <Divider></Divider>
                    <DialogContentText id="alert-dialog-description">
                       <div container spacing={1} style={{paddingBottom:"10px" ,display:"flex"}}>
                           <div item xs={5}  style={{display:"grid",flexBasis:"10%",overflowY:"auto",padding:"15px" }} >
                                {productInfo && productInfo.images && productInfo?.images.map((image)=>{
                                    return  <img   onClick={(e)=>changeImage(image)} src={image} style={{width:"50%",height:"50%",cursor:"pointer"}} ></img>

                                    // <CardMedia
                                    //     onClick={(e)=>changeImage(image)}
                                    //     component="img"
                                    //     image={image} 
                                    //     sx={{width:"30%",height:"30%"}} 
                                    // /> 
                                })}
                            </div>
                            <div item xs={6}  style={{ minWidth: "150px",flexBasis:"30%",padding:"5px" }} >
                                <CardMedia
                                    component="img"
                                    image={selectedImage}
                                    sx={{width:"100%",height:"100%"}}
                                />
                            </div>
                       
                            <TabContext sx={{flexBasis:"60%", display:"block"}} value={value}>
                                <div style={{flexBasis:"60%", display:"block"}}>
                                    <Tabs  sx={{fontSize:"12px",color:"#000058 !important"}} value={value} onChangeIndex={handleTabs} >
                                        <Tab sx={{fontSize:"12px",color:"#000058 !important"}} label="Basic Information"></Tab>
                                        <Tab sx={{fontSize:"12px",color:"#000058 !important"}}  label="Price"></Tab>
                                    </Tabs>
                                    <TabPanel  sx={{fontSize:"12px"}} value={value} index={0}>
                                        <p>Product Id: {productInfo.id}</p>
                                        <p>Brand: {productInfo.brand}</p>
                                        <p>Product Description: {productInfo.description}</p>
                                        <p>Internal Storage: {productInfo.internalStorage}</p>
                                        <p>Product Description: {productInfo.description}</p>
                                        <p>Sim Type: {productInfo.simType}</p>
                                        <p>Price: {productInfo.price}</p>
                                        <p>OrderQuantity: {productInfo.stock}</p>
                                        <p>Network Type: {productInfo.stock}</p>
                                        
                                    </TabPanel>
                                </div>
                                
                                {/* <TabPanel   sx={{fontSize:"12px"}} value={value} index={1}>
                                    <h4>Product Description: {productInfo.description}</h4>
                                </TabPanel>
                                <TabPanel   sx={{fontSize:"12px"}} value={value} index={2}>
                                    <h4>Price: {productInfo.price}</h4>
                                    <h4>OrderQuantity: {productInfo.orderQuantity}</h4>
                                </TabPanel> */}
                                </TabContext>
                        </div>
                    </DialogContentText>
                </DialogContent>
                
            </div>
        </Dialog>
    </div>
    )
}
export default ProductInfo;