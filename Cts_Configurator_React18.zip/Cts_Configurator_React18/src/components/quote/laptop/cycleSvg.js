import { Button, Divider, FormControl, InputLabel, MenuItem, Select } from "@mui/material";
import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import cycle from '../../../assets/images/cycle/wheel.svg'
import { ReactSVG } from 'react-svg'
import { TransformWrapper, TransformComponent } from "react-zoom-pan-pinch";
const CycleSvg =()=>{
    const [color,setColor]=useState("white");
    const [item,setItem]=useState(null)
    const newitem=[
        {
            name:"Tire Color",
            label:"Tire Color",
            selectedValue:"black",
            options:[
                {name:"black",value:"black"},
                {name:"red",value:"red"},
                {name:"green",value:"green"},
                {name:"blue",value:"#000048"},
                {name:"yellow",value:"yellow"},
            ]
        },
        {
            name:"Rim Color",
            label:"Rim Color",
            selectedValue:"black",
            options:[
                {name:"black",value:"black"},
                {name:"red",value:"red"},
                {name:"green",value:"darkgreen"},
                {name:"blue",value:"#000048"},
                {name:"grey",value:"grey"},
            ]
        },
        {
            name:"Rim Option",
            label:"Rim Option",
            selectedValue:"Yes",
            options:[
                {name:"Yes",value:"Yes"},
                {name:"No",value:"No"},
            ]
        },
        {
            name:"Tire Option",
            label:"Tire Option",
            selectedValue:"Yes",
            options:[
                {name:"Yes",value:"Yes"},
                {name:"No",value:"No"},
            ]
        },

    ]
    useEffect(()=>{
        setItem(newitem);
    },[])
    const handleChangeDropDown=(e,currentItem)=>{
        var item1=[...item]
        item1.forEach((value)=>{
            if(value.name==currentItem.name){
                value.selectedValue=e.target.value;
            }
        })
        // item1.selectedValue=e.target.value;
        setItem(item1);
        setColor(e.target.value);

    }
    return(
        <>
        <div style={{margin:"68px 8px 8px 8px",color:"#000048"}}>Configure Bicycle</div>
        <Divider></Divider>
        <div style={{display:"flex"}}>
        {item &&<div style={{margin:"1% 1% 4% 1%",background:"white",padding:"5px",height:"70vh"}} >
            {item.map((itemm)=>{

            return <>
            <InputLabel sx={{margin:"8px 8px 8px 8px",fontSize:"12px",color:"#000048"}} id="demo-simple-select-standard-label">{itemm.name}</InputLabel>
            <FormControl variant="standard" sx={{ m:1, minWidth: 300 }}>
                <Select
                    labelId="demo-simple-select-standard-label"
                    id="demo-simple-select-standard"
                    value={itemm.selectedValue}
                    onChange={(e)=>handleChangeDropDown(e,itemm)}
                    sx={{fontSize:"12px !important",color:"#000048"}}
                >
                {itemm.options.map((option,menuindex)=>{
                    return (
                        <MenuItem sx={{fontSize:"12px",color:"#000048"}} value={option.value}>{option.name}</MenuItem>
                    )
                    })
                }
                </Select>
            </FormControl>
            </>
            })}
            </div>
            }
            <div style={{ margin:"1% 0% 0% 0%",width:'71%'}}>
                <TransformWrapper
                    initialScale={0.5}
                    initialPositionX={200}
                    initialPositionY={100}
                    centerOnInit={true}
                >
                    {({ zoomIn, zoomOut, resetTransform, ...rest }) => (
                    <>
                        <div style={{background:"white",height:"71.5vh",}}>
                            <div style={{display:"flex",padding:"5px 3px 20px 12px"}}>
                                <div style={{padding:"2px"}}><Button sx={{background:"#000048",color:"white",padding:"3px"}} onClick={() => zoomIn()}>+</Button></div>
                                <div style={{padding:"2px"}}><Button sx={{background:"#000048",color:"white",padding:"3px"}} onClick={() => zoomOut()}>-</Button></div>
                                <div style={{padding:"2px"}}><Button sx={{background:"#000048",color:"white",padding:"3px"}} onClick={() => resetTransform()}>x</Button></div>
                            </div>
                            <TransformComponent>
                            <div  style={{margin:"-27% 0% 0% 0%",padding:"3px"}}>
                                <ReactSVG
                                    afterInjection={(svg) => {
                                        // var data=svg.getElementById("wheel-layer-1");
                                        // var color=newitem!=null?newitem.selectedValue:"red";
                                        // data.style.fill=newitem!=null?newitem.selectedValue:"red";;
                                    }}
                                    beforeInjection={(svg) => {
                                        //svg.classList.add('svg-class-name')
                                        //svg.setAttribute('style', 'width: 200px')
                                        var data=svg.getElementById("wheel-layer-1");
                                        data.style.fill=item!=null?item[0].selectedValue:"red";
                                        data.style.display=item!=null && item[3].selectedValue==="Yes"?"block":"none";
                                        var data1=svg.getElementById("wheel-spring-1");
                                        data1.style.fill=item!=null?item[1].selectedValue:"red";
                                        data1.style.display=item!=null && item[2].selectedValue==="Yes"?"block":"none";
                                        
                                    }}
                                    className="wrapper-class-name"
                                    desc="Description"
                                    evalScripts="always"
                                    fallback={() => <span>Error!</span>}
                                    httpRequestWithCredentials={true}
                                    loading={() => <span>Loading</span>}
                                    onClick={() => {
                                        console.log('wrapper onClick')
                                    }}
                                    onError={(error) => {
                                        console.error(error)
                                    }}
                                    renumerateIRIElements={false}
                                    src={cycle}
                                    title="Title"
                                    useRequestCache={false}
                                    wrapper="span"
                                    />
                            </div>
                            </TransformComponent>
                        </div>
                    </>
                    )}
                </TransformWrapper>
                </div>
        </div>
        </>
    )
}
export default CycleSvg;