import React from "react";
import { Dialog,DialogTitle,DialogContent ,DialogContentText,Button,DialogActions} from "@mui/material";

const ConflictMessage=(props)=>{
    

    return(
        <>
              <Dialog
                    open={props.conflict.open}
                    onClose={props.handleClickCancel}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                    fullWidth={"md"}
                >
                    <DialogTitle sx={{fontSize:"12px"}} id="alert-dialog-title">
                    {props.conflict.title}
                    </DialogTitle>
                    <DialogContent>
                    <DialogContentText sx={{fontSize:"12px"}} id="alert-dialog-description">
                       {props.conflict.isConflict  && 
                       <div style={{fontSize:"12px",display:"flex"}}>
                            <div> {props.conflict.message +"-  "}</div>
                            <div>{props.conflict.conflictVariable +":"+props.conflict.conflictValue+" "}</div>
                            <div>{"Screen Size:15.6 Inch"}</div>
                       </div>}
                     
                    </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                    <Button onClick={props.handleClickOK}>Ok</Button>
                    <Button onClick={props.handleClickCancel} autoFocus>
                        Cancel
                    </Button>
                    </DialogActions>
            </Dialog>
        </>
    )
}
export default ConflictMessage;