import React from "react";


export function getHardDiskImage(value){

    return (
        <>
        {/* <svg width="400" height="110">
            <rect width="300" height="100" style={{fill:"white",strokeWidth:3,stroke:"blue"}}/>
            <text x="50" y="50" fill="blue">1000 GB</text>
        </svg> */}
        <svg width="100" height="120">
            <rect x="0" y="0" width="100" height="120" style={{fill:"lightBlue",stroke:"lightBlue",strokeWidth:5,fillOpacity:0.1,strokeOpacity:0.9}} />
            <circle cx="50" cy="60" r="20" stroke="lightBlue" stroke-width="4" fill="white" />
            <circle cx="50" cy="60" r="5" stroke="lightBlue" stroke-width="4" fill="white" />
            <text x="50%" y="80%" fill="lightBlue" dominant-baseline="middle" text-anchor="middle">{value}</text>
        </svg>
        </>
        
    )
   
}
    
