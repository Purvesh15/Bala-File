import React from "react";
import {Alert, Snackbar } from "@mui/material";

const Message=(props)=>{

    return(
        <Snackbar
            sx={{ alignItems:"right",marginBottom:"4vh"}}
            open={props.open}
            autoHideDuration={2000}
            anchorOrigin={{
                vertical: "bottom",
                horizontal: "center"
            }}
            onClose={()=>props.handleCloseMessage()}
            message={props.message}
        >
        <Alert onClose={()=>props.handleCloseMessage()} autoHideDuration={3000} sx={{color:"white", backgroundColor:'#000048'}}>{props.message}</Alert>
        </Snackbar>
    )
}
export default Message;