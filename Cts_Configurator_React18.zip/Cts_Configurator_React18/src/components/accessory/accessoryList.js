import React,{useEffect, useState} from 'react';
import { styled } from '@mui/material/styles';
import {Button,Box, Divider, FormControl, OutlinedInput} from '@mui/material';
import { useNavigate } from 'react-router-dom';

const AccessoryList =(props)=>{
    const navigate= useNavigate();
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [accessoryCount,SetAccessoryCount]=useState(0);
    
    useEffect(()=>{
      SetAccessoryCount(props.accessories.length)
    })
    const handleChangePage = (event, newPage) => {
      setPage(newPage);
    };
    
    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };
    const addAccessoryCart=()=>{
      props.addToCart(props.accessories);
    }
    const handleClickConfigure=()=>{
        navigate('/cart');
    }
  return (
    <>
    <Box sx={{ width:'-webkit-fill-available',overflow:"hidden"}}>
      <Button sx={{cursor:"pointer",background:"darkblue",height:"28px",width:"120px !important"}} size="small" variant="contained" onClick={()=>addAccessoryCart()}>Add to Cart</Button>
      <Divider  sx={{color:"darkblue"}}/>
        <Box sx={{fontSize:"12px",display:"flex",paddingTop:"10px",color:"darkblue",fontWeight:500}}>
            <div style={{flexBasis:"9%"}}>Image</div>
            <div style={{flexBasis:"20%"}}>Accessory Id</div>
            <div style={{flexBasis:"28%"}}>Description</div>
            <div style={{flexBasis:"19%"}}>Price</div>
            <div style={{flexBasis:"13%"}}>Quantity</div>
            <div style={{flexBasis:"10%"}}>Net Price</div>
        </Box>
      <Divider sx={{paddingTop:"10px",color:"darkblue"}}/>
      <Box sx={{height:"50vh",overflow:"auto",overflowX:"hidden"}}>
      {props.accessories.map((product)=>{
        return (
        <Box sx={{display:"flex",paddingTop:"5px",alignItems:"center",fontSize:"12px"}}>
            <div style={{flexBasis:"8%"}}><img width={40} src={product.image}></img></div>
            <div style={{flexBasis:"21%"}}>{product.id}</div>
            <div style={{flexBasis:"30%"}}>{product.shortDescrtiption}</div>
            <div style={{flexBasis:"19%"}}>{product.Price}</div>
            {/* <TextField   sx={{flexBasis:"10%",padding:1}} id="outlined-quantity" label="" variant="outlined" /> */}
            <FormControl sx={{flexBasis:"15%", width: '5ch' }}>
              <OutlinedInput value={product.orderQuantity} sx={{fontSize:"12px",width:'80px !important',height:"30px"}} />
            </FormControl>
            <div style={{flexBasis:"10%"}}>{parseInt(product.Price)*parseInt(product.orderQuantity)}</div>
        </Box>
        )
      })
        
      }
    </Box>
    </Box>
    </>
  );
}
export default AccessoryList;