import React,{useEffect, useState} from 'react';
import { styled } from '@mui/material/styles';
import { useNavigate } from 'react-router-dom';
import {TextField,Button,Box, Divider, FormControl, OutlinedInput,Card, Grid, CardActionArea, CardContent, Typography, CardMedia } from '@mui/material'
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';
import { useSelector } from 'react-redux';
const AccessoryProduct =(props)=>{
    const navigate= useNavigate();
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [accessoryCount,SetAccessoryCount]=useState(0);
    const [accessoryPrice,setAccessoryPrice]=useState(0);
    const salesArea=useSelector(state=>state.app.salesArea);
    useEffect(()=>{
      SetAccessoryCount(props.accessories.length);
      if(props.accessories.length>0){
        var totalPrice=0;
        props.accessories.forEach(accessory => {
          totalPrice+=parseInt(accessory.Price);
        });
        totalPrice=totalPrice.toFixed(2);
        setAccessoryPrice(totalPrice);
      }
    })
    const handleChangePage = (event, newPage) => {
      setPage(newPage);
    };
    
    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };
    const addAccessoryCart=(e,accessory)=>{
      props.addToCart(accessory);
    }
    const handleClickConfigure=()=>{
        navigate('/cart');
    }
  return (
    <>
    {/* <div style={{color:"darkBlue",fontWeight:"600",padding:"3px"}}>Total Accessories ({ accessoryCount}) </div> */}
      <Box sx={{width:'-webkit-fill-available',overflow:"hidden"}}>
        <div style={{display:"flex",color:"white",paddingTop:"10px",justifyContent:"end",}}>
            {/* <div onClick={(e)=>addAccessoryCart()} style={{opacity:"0.9", boxShadow:"0 1px 5px 0 rgb(0 0 0 / 11%)", borderRadius:"3px", textAlign:"center",padding:"6px",cursor:"pointer",background:"#000048",height:"fit-content",width:"40%"}}>
                <AddShoppingCartIcon sx={{width:"25px",height:"22px"}}></AddShoppingCartIcon>
                <div style={{fontSize:"12px"}}>Add To Cart</div>
            </div> */}
            <div style={{fontSize:"12px",opacity:"0.9", boxShadow:"0 1px 5px 0 rgb(0 0 0 / 11%)", borderRadius:"3px",marginLeft:"30%",textAlign:"center",padding:"10px",cursor:"pointer",background:"#000048",height:"fit-content",width:"40%"}}>
                <div>Accessory Price</div>
                <div style={{paddingTop:"5px"}}>{salesArea.currency+" "+accessoryPrice}</div>
            </div>
        </div>
      <Box>
      <Divider  sx={{paddingTop:"5px",color:"lightgrey"}}/>
      <Grid container spacing={2} style={{marginTop:"1px"}}> 
            {props.accessories.length>0 && 
                props.accessories.map((family)=>{
                   return(
                    <Grid item xs={2}  style={{minWidth:"200px",minHeight:"200px"}} >
                        <Card >
                            <CardActionArea >
                                <CardMedia 
                                component="img"
                                image={family.image}
                                sx={{height:"80px",objectFit:"contain"}}
                                />
                                <CardContent sx={{height:"70px",textAlign:"center"}}>
                                    <Typography sx={{fontSize:"12px"}} align="center" gutterBottom variant="body2" component="div" >
                                      {family.name}
                                    </Typography>
                                    <Divider></Divider>
                                    <div style={{display:"flex",padding:"3px"}}>
                                    
                                    <FormControl sx={{flexBasis:"50%",paddingTop:"6px"}}>
                                    <OutlinedInput  onChange={(e)=>props.changeQuantity(e,family)} type="text" value={family.orderQuantity}  sx={{padding:"5px",fontSize:"12px",width:'70px !important',height:"20px",textAlignLast:"center !important"}}/>
                                    </FormControl>
                                    <Typography sx={{maxWidth:"90px",paddingTop:"6px",flexBasis:"50%",fontWeight:'bold',fontSize:"14px",color:"black"}} align="end" variant="body2" color="text.secondary">
                                      {salesArea.currency+" "+ family.Price}
                                    </Typography>
                                    </div>
                                    <AddShoppingCartIcon onClick={(e)=>addAccessoryCart(e,family)} sx={{padding:"2px"}}></AddShoppingCartIcon>
                                </CardContent>
                            </CardActionArea>
                        </Card>
                    </Grid> )

                })
            }
           
            </Grid> 

      </Box>
           {props.accessories.length==0&&
                <Typography sx={{fontSize:"12px",textAlign:"center",paddingTop:"30%"}}>No Accessories Added Yet....</Typography>
            }
    </Box>
    </>
  );
}
export default AccessoryProduct;