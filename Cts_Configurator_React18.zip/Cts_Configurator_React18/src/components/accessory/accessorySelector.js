import React, { useState } from 'react';
import {Tabs,Box,Tab,Select,InputLabel,MenuItem,FormControl, Button} from '@mui/material';
import ClearIcon from '@mui/icons-material/Clear';

const AccessorySelector=(props)=>{
    return(
        <div style={{padding:"0px 10px 0px 10px",background:"white",flexBasis:"60%",boxShadow:"0 1px 5px 0 rgb(0 0 0 / 11%)"}} >
            <Box sx={{ fontSize:"13px", maxWidth: "800px", bgcolor: 'background.paper' }}>
                <Tabs
                    value={props.tabIndex}
                    variant="scrollable"
                    scrollButtons="auto"
                    aria-label="scrollable auto tabs example" 
                >
                {props.accTab.map((tab,index)=>{
                    return  <Tab onClick={()=>props.handleChangeTab(index)} sx={{fontSize:"10px" ,borderBottom:"solid 1px lightgrey"}} label={tab} />
                    })
                }
                </Tabs>
            </Box>
            <div style={{textAlign:"end"}}>
               <Button sx={{fontSize:"12px",color:"#000048"}} onClick={()=>props.resetAll()}>Reset</Button>
            </div>
            <Box  sx={{marginLeft:"30px",display:"flex",flexFlow:"wrap"}}>
            {props.accessorySelector.length>0 && props.accessorySelector[props.tabIndex].configuration && props.accessorySelector[props.tabIndex].configuration.map((item,index)=>{
                    return (
                        <>
                         <Box  sx={{display:"block"}}>
                           <InputLabel sx={{ width:"280px",margin:"12px 8px 0px 8px",fontSize:"11px",color:"black"}} id="demo-simple-select-standard-label">{item.name}</InputLabel>
                            <FormControl variant="standard" sx={{ margin:"5px 8px 0px 8px", minWidth: 320,display:"flex",flexDirection:"row"}}>
                                <Select
                                labelId="demo-simple-select-standard-label"
                                id="demo-simple-select-standard"
                                value={item.selectedValue}
                                onChange={(e)=>props.handleChangeDropDown(e,item)}
                                sx={{width:"-webkit-fill-available",fontSize:"12px !important"}}
                                >
                                {item.options.map((option,menuindex)=>{
                                        return (
                                            <MenuItem sx={{fontSize:"11px"}} value={option.name}>{option.value}</MenuItem>
                                        )
                                    })
                                }
                                </Select>
                                <span><ClearIcon sx={{display:"flex",fontSize:"16px",color:"lightgray",cursor:"pointer",alignSelf:"center",position:"relative",margin:"9px 0px 0px 2px"}}></ClearIcon></span>
                            </FormControl>
                            </Box>
                        </>
                    )}
                )
                }
             
            
            {/* {props.accessorySelector[tabIndex].configuration.length===0 && 
              <div style={{padding:"20% 0% 0% 35%"}}>No Configuration Found !</div>
            } */}
        </Box>
        </div>
    )
}
export default AccessorySelector;