import React, { useEffect, useState } from 'react';
import {Slider,FormControlLabel,TextField,ListItemText,Checkbox,OutlinedInput,Radio,Select,NativeSelect,InputLabel,MenuItem,FormControl, Button} from '@mui/material';
import { borderRadius, margin } from '@mui/system';
import './productSelector.css'
import ClearIcon from '@mui/icons-material/Clear';
const ProductSelector=(props)=>{
    const [productSelector1,setProductSelector]=useState([]);
    const MenuProps = {
        PaperProps: {
          style: {
            maxHeight: 48 * 4.5 + 40,
            width: 250,
          },
        },
      };
    useEffect(()=>{
        setProductSelector(props.productSelector);
    },[]);
    return(
        <div className='prod-selector-main' >
            <div style={{textAlign:"end"}}>
               <Button sx={{fontSize:"12px",color:"#000048"}} onClick={()=>props.resetAll()}>Reset</Button>
            </div>
            {props.productSelector.map((item)=>{
                return (
                    <>
                       {item.type=="dropdown" &&
                       <>
                        <InputLabel sx={{margin:"8px 8px 8px 8px",fontSize:"12px",color:"black"}} id="demo-simple-select-standard-label">{item.name}</InputLabel>
                        <FormControl variant="standard" sx={{ m:1, minWidth: 200 ,display:"flex !important",flexDirection:"row"}}>
                            <Select
                                labelId="demo-simple-select-standard-label"
                                id="demo-simple-select-standard"
                                value={item.selectedValue}
                                onChange={(e)=>props.handleChangeDropDown(e,item)}
                                sx={{width:"-webkit-fill-available",fontSize:"12px !important"}}
                                isClearable={true}
                            >
                          
                            {item.options.map((option,menuindex)=>{
                                    return (
                                         <MenuItem sx={{fontSize:"12px"}} value={option.name}>{option.value}</MenuItem>
                                    )
                                })
                            }
                            </Select>
                            <span><ClearIcon  onClick={(e)=>props.reset(e,item)} sx={{fontSize:"17px",color:"lightgray",cursor:"pointer",alignSelf:"center"}}></ClearIcon></span>
                        </FormControl>
                        </>
                        }
                        {item.type=="radio"&& 
                            <>
                                <InputLabel sx={{marginLeft:"8px",fontSize:"12px",color:"black"}} id="demo-simple-select-standard-label">{item.name}</InputLabel>
                                {item.options.map((option,index)=>{
                                    return <FormControlLabel
                                        sx={{marginLeft:"1px",fontSize:"12px !important"}}
                                        value={option.value}
                                        control={
                                        <Radio onChange={(e)=>props.handleChangeDropDown(e,item)}
                                           sx={{marginLeft:"1px",fontSize:"12px !important"}} size="small" checked={option.value==item.selectedValue}
                                        />}
                                        label={option.value}
                                        labelPlacement="Top"
                                        />
                                })}
                            </>
                        }
                        {item.type=="multidropdown" &&
                            <>
                            <InputLabel  sx={{marginLeft:"8px",fontSize:"12px",color:"black"}} id="demo-multiple-checkbox-label">{item.name}</InputLabel>
                            <FormControl sx={{ m: 1, width: 300 }}>
                            <Select
                              labelId="demo-multiple-checkbox-label"
                              id="demo-multiple-checkbox"
                              multiple
                              value={item.selectedValue}
                              renderValue={(selected) => selected.join(', ')}
                              MenuProps={MenuProps}
                              variant="standard"
                            >
                              {item.options.map((option) => {
                                return (<MenuItem key={option.name} value={option.name}>
                                  <Checkbox  onChange={(e)=>props.handleChangeDropDown(e,item)} sx={{padding:"2px",fontSize:"12px !important"}}checked={item.selectedValue.indexOf(option.name) > -1} />
                                  <ListItemText disableTypography={true} style={{padding:"2px",fontSize:"12px !important"}} primary={option.name} />
                                </MenuItem>
                                )})
                               }
                            </Select>
                          </FormControl>
                          </>
                        }
                        {item.type=="range" && 
                        <>
                           <InputLabel sx={{margin:"8px 8px 8px 8px",fontSize:"12px",color:"black"}} id="demo-simple-select-standard-label">{item.name}</InputLabel>
                           <Slider  min={10} max={3000} onChange={(e)=>props.handleChangeDropDown(e,item)}  sx={{margin:"8px 8px 8px 8px",ontSize:"12px",width:"95%"}} defaultValue={item.selectedValue} aria-label="Default" valueLabelDisplay="auto" />  
                        </>
                        }

                    </>
                )})}
        
        </div>
    )
}
export default ProductSelector;