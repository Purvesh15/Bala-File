import React from 'react';
import {Card, Grid, CardActionArea, CardContent, Typography, CardMedia, Divider, FormControl, OutlinedInput } from '@mui/material'
import { useEffect, useState } from 'react'
import BuildIcon from '@mui/icons-material/Build';
import { Box } from '@mui/system';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';
import Info from '@mui/icons-material/Info';
import { setProductInfo } from '../../actions/appAction';

const ProductGrid=(props)=>{
    const dispatch =useDispatch();
    const [productCount ,setCount]=useState(0);
    const [open,setOpen]=useState(false);
    const salesArea=useSelector(state=>state.app.salesArea)
    useEffect(()=>{
        setCount(props.products.length) 
    },[])
    const handleClickProduct=()=>{
        console.log("");
    }
    const handleClickCart=(product)=>{
        props.addToCart(product);
    }
    const handleClickOpen=(product)=>{
        dispatch(setProductInfo(product));
    }
    return(
        <>
        <div>
        <div className='product-count'>Products ({ props.products.length}) </div>
        <Grid container spacing={1} style={{ marginTop:"1px"}}> 
            {props.products.length>0 && 
                props.products.map((product)=>{
                   return(
                    <Grid item xs={2.4} onClick={()=> handleClickProduct(product,true)} style={{minWidth:"150px"}} >
                        <Card>
                            <CardActionArea >
                                <CardMedia
                                    component="img"
                                    height="140"
                                    image={product.thumbnail}
                                />
                                <CardContent>
                                    <Typography sx={{fontSize:"12px"}} align="center" gutterBottom variant="body2" component="div" >
                                      {product.title}
                                    </Typography>
                                    <Typography sx={{fontSize:"12px",height:"30px",overflow:"hidden",paddingBottom:"4px"}} align="center" variant="body2" color="text.secondary">
                                      {product.description}
                                    </Typography>
                                    <Divider></Divider>
                                    <Box sx={{display:"flex",paddingTop:"10px"}}>
                                        <FormControl sx={{flexBasis:"30%",paddingTop:"6px"}}>
                                        <OutlinedInput  onChange={(e)=>props.changeProductQuantity(e,product)} type="text" value={product.stock}  sx={{padding:"5px",fontSize:"12px",width:'60px !important',height:"20px",textAlignLast:"center !important"}}/>
                                        </FormControl>
                                        <Typography sx={{alignSelf:"end",paddingTop:"6px",flexBasis:"70%",fontWeight:'bold',fontSize:"14px",color:"#2E308E"}} align="end" variant="body2" color="text.secondary">
                                        {salesArea.currency+" "+ product.price}
                                        </Typography>
                                    </Box>
                                    <Box sx={{display:"flex",paddingTop:"10px"}}>
                                        <BuildIcon sx={{color:"#2E308E",display:"flex",flexBasis:"33%",cursor:"pointer"}} onClick={(e)=>props.handleClickConfigure(product)}></BuildIcon>
                                        <AddShoppingCartIcon sx={{color:"#2E308E",display:"flex",flexBasis:"36%",cursor:"pointer"}}  onClick={(e)=>handleClickCart(product)}></AddShoppingCartIcon>
                                        <Info color='primary' sx={{color:"#2E308E", display: "flex", flexBasis: "30%", cursor: "pointer" }} onClick={(e)=>handleClickOpen(product)} ></Info>
                                    </Box>
                                </CardContent>
                            </CardActionArea>
                        </Card>
                    </Grid> )

                })
                }
        </Grid> 
        </div>
    </>
 )
}
export default ProductGrid; 