import React,{useState} from 'react';
import { styled } from '@mui/material/styles';
import {Box,List,ListItem, ListItemButton,ListItemText,Paper, Divider, FormControl, OutlinedInput} from '@mui/material';
import BuildIcon from '@mui/icons-material/Build';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { useNavigate } from 'react-router-dom';
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';
import { useSelector } from 'react-redux';

const ProductTable =(props)=>{
    const navigate= useNavigate();
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const salesArea=useSelector(state=>state.app.salesArea);
    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };
    const handleClickCart=(product)=>{
        props.addToCart(product);
    }
  return (
    <>
    <Box className='product-table-main'>
      <Divider  sx={{color:"darkblue"}}/>
      <Box sx={{fontSize:"12px",display:"flex",paddingTop:"10px",color:"darkblue",fontWeight:500}}>
          <div style={{flexBasis:"11%"}}>Image</div>
          <div style={{flexBasis:"22%"}}>Product Id</div>
          <div style={{flexBasis:"28%"}}>Description</div>
          <div style={{flexBasis:"10%"}}>Price</div>
          <div style={{flexBasis:"10%"}}>Quantity</div>
          <div style={{flexBasis:"10%"}}></div>
      </Box>
      <Divider sx={{paddingTop:"10px",color:"darkblue"}}/>
      <Box sx={{height:"70vh",overflow:"auto",overflowX:"hidden"}}>
      {props.products && props.products.map((product)=>{
        return (
        <Box sx={{display:"flex",paddingTop:"5px",alignItems:"center",fontSize:"12px"}}>
            <div style={{flexBasis:"14%",padding:"5px"}}><img width={40} src={product.thumbnail}></img></div>
            <div style={{flexBasis:"18%",padding:"5px"}}>{product.brand}</div>
            <div style={{flexBasis:"40%",padding:"5px"}}>{product.description}</div>
            <div style={{flexBasis:"15%",padding:"5px"}}>{salesArea.currency+" "+product.price}</div>
            <FormControl sx={{flexBasis:"10%", width: '5ch',padding:"5px"}}>
              <OutlinedInput onChange={(e)=>props.changeProductQuantity(e,product)} value={product.stock} sx={{fontSize:"12px",textAlign:"center",height:"30px",textAlignLast:"center !important"}} />
            </FormControl>
            <BuildIcon  style={{padding:"5px",flexBasis:"10%",cursor:"pointer"}} color='primary' onClick={(e)=>props.handleClickConfigure(product)}></BuildIcon>
            <AddShoppingCartIcon  style={{flexBasis:"10%",cursor:"pointer"}}onClick={(e)=>handleClickCart(product)}></AddShoppingCartIcon>
        </Box>
        )
      })
        
      }
    </Box>
    </Box>

    </>
  );
}
export default ProductTable;