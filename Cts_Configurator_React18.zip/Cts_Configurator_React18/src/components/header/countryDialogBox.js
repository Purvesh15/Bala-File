import React,{useState} from 'react'
import {InputLabel,Select,FormControl,MenuItem,Button,Box,Dialog,DialogContent,DialogTitle,DialogContentText,DialogActions} from '@mui/material';
import { useSelector } from 'react-redux';

const CountryDialogBox=(props)=>{
    const t=useSelector(state=>state.app.translation)
    return(
        <>
        <Dialog
            fullWidth={true}
            maxWidth={'sm'}
            open={props.open}
            onClose={props.handleCloseLanguageDialog}
        >
        <DialogTitle sx={{color:"darkblue"}}>{t.menubar.languagePopup}</DialogTitle>
        <DialogContent>
          <Box
            noValidate
            component="form"
            sx={{
              display: 'flex',
              flexDirection: 'column',
              m: 'auto',
            }}
          >
            {props.settingsArray &&
              props.settingsArray.map((array)=>{
                return <FormControl sx={{ mt: 2, minWidth: 120 }}>
                <InputLabel htmlFor="language">{array.name}</InputLabel>
                <Select
                  autoFocus
                  value={props.currentLanguage}
                  onChange={(e)=>props.handleChangeLanguage(e,array)}
                  label={array.name}
                >
                  {array.options.map((option)=>{
                    return <MenuItem currency={option.currency} option={option} value={option.value}>{option.value}</MenuItem>
                  })}
                </Select>
              </FormControl>
            })
                
            }
            
           
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={props.handleCloseLanguageDialog}>{t.menubar.close}</Button>
        </DialogActions>
      </Dialog>
        
        </>
    )
}

export default CountryDialogBox;