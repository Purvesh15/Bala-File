import React from 'react';
import {Box,AppBar,Toolbar ,InputBase,Paper,Menu,MenuItem,Divider,MenuList, Button} from '@mui/material';
import AccountBoxIcon from '@mui/icons-material/AccountBox';
import SettingsIcon from '@mui/icons-material/Settings';
import ExitToAppIcon from '@mui/icons-material/ExitToApp';
import { useSelector } from 'react-redux';
import { useEffect, useState } from 'react';
const MenuBar=(props)=>{
    const app=useSelector(state=>state.app);
    const [user,setUser]=useState(null);
    const t=useSelector(state=>state.app.translation)
    useEffect(()=>{
        if(app.userDetails!=null){
            setUser(app.userDetails[0]);
        }
    },[])
    return(
        <>
            <Paper id="cts_menubar"  sx={{marginTop:"4%",position:"absolute",float:"right",marginLeft:"84%",background:"white", width: 200,zIndex:1000 }}>
                <div style={{height:"60px", background:"#000048",display:"block",color:"white"}}>
                    <MenuItem sx={{fontSize:"11px !important"}}  >{user ?user.name:""}
                    </MenuItem>
                    <MenuItem sx={{fontSize:"11px !important"}}  >{user?user.email:""}
                    </MenuItem>
                </div>
                <MenuList sx={{padding:"0px 15px 0px 15px"}}>
                <Divider></Divider>
                <div style={{padding:"10px",display:"flex"}}><AccountBoxIcon sx={{color:"#000048",marginTop:"6px"}}></AccountBoxIcon><MenuItem sx={{fontSize:"14px !important"}}  >{t.menubar.profile}</MenuItem></div>
                <Divider></Divider>
                <div style={{padding:"10px",display:"flex"}}><SettingsIcon sx={{color:"#000048",marginTop:"6px"}}></SettingsIcon><MenuItem sx={{fontSize:"14px !important"}} onClick={(e)=>props.handleClickLanguage(e)}>{props.language}</MenuItem></div>
                <Divider></Divider>
                <div style={{padding:"10px",display:"flex"}}><ExitToAppIcon sx={{color:"#000048",marginTop:"6px"}}></ExitToAppIcon><MenuItem sx={{fontSize:"14px !important"}}  >{t.menubar.logout}</MenuItem></div>
                <Divider></Divider>
                </MenuList>
            </Paper>
        </>

    )
}
export default MenuBar;