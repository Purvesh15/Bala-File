import React from "react";
import './filterResult.css';

const FilterResult=(props)=>{
   
   return(
    <div className='filter-result-content'>
        {props.searchResults.map((item)=>{
            return <div className="filter-result-label" onClick={(e)=>props.handleSearch(e)}  value={item} >{item}</div>
        })}
    </div>
   )
}
export default FilterResult;