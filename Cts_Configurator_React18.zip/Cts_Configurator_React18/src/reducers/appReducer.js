const initState = {
  userDetails:null,
  currentPage: 0,
  navFamily:[],
  currentFamily:null,
  cartItems:[],
  productFamilies:null,
  productInfo:null,
  translation:null,
  appLanguage:'en',
  salesArea:{name:"United States" ,value:"US",currency:"$"},
  productConfigurations:null,
  accessoryConfigurations:null,
}
  
const AppReducer = (state=initState,action) => {
  switch (action.type){
     case "UPDATE_USER":
        return {
          ...state,
          userDetails: action.userDetails
        }
      case "CHANGE_NAVIGATION":
        return {
          ...state,
          currentPage: action.currenPage
      }
      case "SET_NAV_FAMILY":
        return {
          ...state,
          navFamily: action.navFamily
      }
      case "SET_CURRENT_FAMILY":
        return {
          ...state,
          currentFamily: action.currentFamily
      }
      case "ADD_CART_ITEM":
        return {
          ...state,
          cartItems: action.cartItems
      }
      case "SET_PRODUCT_FAMILY":
        return {
          ...state,
          productFamilies: action.productFamilies
      }
      case "SET_PRODUCT_INFO":
        return {
          ...state,
          productInfo: action.productInfo
      }
      case "SET_TRANSLATION":
        return {
          ...state,
          translation: action.translation
      }
      case "SET_APP_LANGUAGE":
        return {
          ...state,
          appLanguage: action.appLanguage
      }
      case "SET_SALES_AREA":
        return {
          ...state,
          salesArea: action.salesArea
      }
      case "SET_PRODUCT_CONFIGURATION":
        return {
          ...state,
          productConfigurations:action.productConfigurations
        }
      case "SET_ACCESSORY_CONFIGURATION":
        return {
          ...state,
          accessoryConfigurations:action.accessoryConfigurations
        }
        
      // you can have as many case statements as you need
      default: 
      return state
  }
}
  
export default AppReducer