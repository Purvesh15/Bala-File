import React, {useEffect, useState} from 'react';
import './configuration.css';
import productSelectorData from '../../assets/json/productSelector.json';
import ProductGrid from '../../components/configuration/productGrid';
import GridViewIcon from '@mui/icons-material/GridView';
import FormatListBulletedIcon from '@mui/icons-material/FormatListBulleted';
import ProductTable from '../../components/configuration/productTable';
import Accessory from '../accessory/accessory';
import ProductSelector from '../../components/configuration/productSelector';
import NavigationBar from '../navigation/navigationBar';
import { addToCartItem, setNavFamily, setProductConfigurations } from '../../actions/appAction';
import {useDispatch,useSelector} from 'react-redux';
import {Button} from '@mui/material'
import { useNavigate } from 'react-router-dom';
import Message from '../../components/common/message';
import productData from '../../assets/json/product.json'
import ProductInfo from '../../components/productInfo/productInfo';
import { v4 as uuidv4, v4 }  from 'uuid';

const Configuration =()=>{
    const dispatch=useDispatch();
    const navigate=useNavigate();
    const [isGridView,setView]=useState(true)
    const [isProductPage,setProductPage]=useState(true)
    const [isOpen ,setOpen]=useState(false);
    const [cartMessage,setMessage] =useState("");
    const [currentProduct,SetCurrentProduct]=useState(null);
    const [products,setProducts]=useState([]);
    const [productSelector,setProductSelector]=useState([]);
    const app = useSelector(state => state.app);
    
    useEffect(()=>{
        // setProductSelector(productSelectorData);
        // var currentData=[];
        // productData.forEach((product)=>{
        //     if(product.category===app.currentFamily){
        //         currentData.push(product)
        //     }
        // })
        // setProducts(currentData)
        initiateData();
    },[]);
    useEffect(()=>{
        setProductSelector(productSelectorData);
        var currentData=[];
        productData.forEach((product)=>{
            if(product.category===app.currentFamily){
                currentData.push(product)
            }
        })
        setProducts(currentData)
        dispatch(setProductConfigurations(productSelectorData));
    },[app.currentFamily]);
    const handleClickConfigure=(product)=>{
        setProductPage(false);
        var familyKeys= JSON.parse(JSON.stringify(app.navFamily));
        //familyKeys.push("123XYZ")
        SetCurrentProduct(product);
        dispatch(setNavFamily(familyKeys));
    }
    const addToCart=(product)=>{
        var newCartItems=[...app.cartItems];
        product.guid=v4();
        newCartItems.push(product);
        dispatch(addToCartItem(newCartItems));
        setOpen(true);
        setMessage(product.brand +"  Product Added to the Cart");
    }
    const handleCloseMessage=()=>{
        setOpen(false);
        setMessage("");
    }
    const handleChangeDropDown=(event,item)=>{
        var productSelectorData1=[...productSelector];
        var count=0;
        productSelectorData1.forEach(data => {
            if( event!=null ){
                if(item.type=="dropdown" && data.name==item.name){
                    data.selectedValue=event.target.value;
                }
                else if(item.type=="radio" && data.name==item.name){
                    data.selectedValue=event.currentTarget.value;
                }
                else if(item.type=="range" && data.name==item.name){
                    data.selectedValue=event.target.value;
                }
                else if(item.type=="multidropdown" && data.name==item.name){
                    data.selectedValue=event.currentTarget.innerText;
                }
            }
            else if(data.name==item.name && event==null ){
                data.selectedValue="";
            }
            if(data.selectedValue && data.selectedValue!=""){
               count++;
            }
        });
        filterProductData(productSelectorData1);
        setProductSelector(productSelectorData1);
        dispatch(setProductConfigurations(productSelectorData1));

    }
    const changeProductQuantity=(e,currentProduct)=>{
        var newProducts=[...products];
        newProducts.forEach((product)=>{
            if(product.thumbnail===currentProduct.thumbnail){
                if(e.target.value!=""){
                    product.stock=parseInt(e.target.value );
                    if(product.unitPrice==undefined){
                        product.unitPrice= product.price
                        product.price= (product.price*parseInt(e.target.value )).toFixed(2);
                    }
                    else{
                        product.price= (product.unitPrice*parseInt(e.target.value )).toFixed(2);
                    }
                }
                else{
                    product.stock=0;
                    if(product.unitPrice==undefined){
                        product.unitPrice= product.price
                    }
                    product.price=0;
                }
                
            }
            
        });
        setProducts(newProducts);
    }
    const initiateData=()=>{
        var newData=[...productSelectorData]
        newData.forEach((data)=>{
            if(data.type=="range"){
                data.selectedValue=10;
            }
            else{
                data.selectedValue="";
            }
        })
        setProductSelector(newData);
        var currentData=[];
        productData.forEach((product)=>{
            if(product.category===app.currentFamily){
                currentData.push(product)
            }
        })
        setProducts(currentData)
    }
    const resetAll=()=>{
        initiateData(true);
    }
    const reset=(e,item)=>{
        var newData=[...productSelector]
        newData.forEach((data)=>{
            if(data.name==item.name){
                data.selectedValue=10;
            }
        });
        setProductSelector(newData);
        filterProductData(newData);
    }
    const filterProductData=(productSelectorData1,isReset)=>{
        var filterProductData=[];
        productData.forEach((prodData,index)=>{
            productSelectorData1.forEach((selector)=>{
                if(prodData.category===app.currentFamily){
                    if( prodData.brand==selector.selectedValue && selector.name=="Brand"){
                        filterProductData.push(prodData);
                    }
                    if(prodData.simType==selector.selectedValue && selector.name=="Sim Type"){
                        filterProductData.push(prodData);
                    }
                    if( prodData.internalStorage==selector.selectedValue && selector.name=="Internal Storage"){
                        filterProductData.push(prodData);
                    }
                    if( prodData.price>0 && prodData.price<=selector.selectedValue && selector.name=="Price Range"){
                        filterProductData.push(prodData);
                    }
                    
                }
                
            })  
        });
        setProducts(filterProductData);
    }
    return (
        <>
            <Message handleCloseMessage={handleCloseMessage} open={isOpen} message={cartMessage} ></Message>
            {isProductPage && 
            <>
            <div className='navbar'><NavigationBar></NavigationBar></div>
            <div className='main'>
                <div className='configureHeader'>
                    <a className='configureLabel'></a>
                    <div className='familyViewOption-config'>
                        <div className={!isGridView?'gridView':'gridView-select'} onClick={()=>setView(!isGridView)}><GridViewIcon sx={{fontSize:"15px"}}></GridViewIcon>Grid View</div>
                        <div className={!isGridView?'treeView-select':'treeView'} onClick={()=>setView(!isGridView)}><FormatListBulletedIcon sx={{fontSize:"15px"}}></FormatListBulletedIcon>List View</div>
                        {/* <Button sx={{height:"22px",width:"65px"}} size="small" variant="contained" onClick={()=>handleCLickCart()}>Cart</Button> */}
                    </div>
                </div>
                <div className='configure-content' >
                    <ProductSelector  productSelector={productSelector} handleChangeDropDown={handleChangeDropDown} resetAll={resetAll} reset={reset}></ProductSelector>
                    {isGridView&& 
                        <div className='configure-grid-content'>
                            <ProductGrid changeProductQuantity={changeProductQuantity} products={products} addToCart={addToCart} handleClickConfigure={handleClickConfigure}></ProductGrid>
                        </div>
                    }
                    {!isGridView&& 
                        <div className='configure-grid-content'>
                            <ProductTable changeProductQuantity={changeProductQuantity} products={products} addToCart={addToCart} handleClickConfigure={handleClickConfigure}></ProductTable>
                        </div>
                    }
                </div>                
            </div>
            </>
        }
        {!isProductPage &&
            <Accessory currentProduct={currentProduct}></Accessory>
        }
        {
            <ProductInfo></ProductInfo>
        }
        </>
        
    )
}
export default Configuration;