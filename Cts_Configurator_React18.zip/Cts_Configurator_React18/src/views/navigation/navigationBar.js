import React from 'react';
import PropTypes from 'prop-types';
import { styled } from '@mui/material/styles';
import Stack from '@mui/material/Stack';
import {Link,Box,Breadcrumbs, getLinkUtilityClass, Divider} from '@mui/material';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Check from '@mui/icons-material/Check';
import SettingsIcon from '@mui/icons-material/Settings';
import GroupAddIcon from '@mui/icons-material/GroupAdd';
import VideoLabelIcon from '@mui/icons-material/VideoLabel';
import StepConnector, { stepConnectorClasses } from '@mui/material/StepConnector';
import {useDispatch,useSelector} from 'react-redux';
import { changeNavigation, setCurrentFamily, setNavFamily } from '../../actions/appAction';
import { useNavigate } from 'react-router-dom';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';

const NavigationBar=()=>{
  const navigate=useNavigate();
  const dispatch=useDispatch();
  const app = useSelector(state => state.app);
  // handleClickLabel=(currentPage)=>{
  //   dispatch(changeNavigation(currentPage));
  //   if(currentPage==0){
  //     navigate('/')
  //   }
  // }
  const handleClickNavigation=(item)=>{
    var newFamilyKeys=[];
    var check=true;
    app.navFamily.forEach(key => {
      if(key!==item && check){
        newFamilyKeys.push(key);
      }
      else if(check){
        newFamilyKeys.push(key);
        check=false;
      }
    });
    dispatch(setNavFamily(newFamilyKeys));
    dispatch(setCurrentFamily(item));
    navigate('/');
  }
  return (
    <>
    <Box sx={{ width: '100%' }}>
    {/* <Stepper activeStep={10} alternativeLabel>
      {app.navFamily.map((label,index) => (
        <Ste key={label}>
          <StepLabel>{label}</StepLabel>
        </Step>
      ))}
    </Stepper> */}
    {app.navFamily && app.navFamily.length>0 &&
      <Breadcrumbs
        separator={<NavigateNextIcon fontSize="small" />}
        aria-label="breadcrumb"
      >
      {app.navFamily.map((item,index)=>{
        var check=false;
        if(app.navFamily.length===index+1){
          check=true;
        }
        return(<Link
        underline="hover"
        key="2"
        color="inherit"
        sx={{cursor:"pointer",fontSize:"12px",color:"darkblue",fontWeight:check?"700":""}}
        onClick={(e)=>handleClickNavigation(item)}
        >
        {item}
        </Link>)})
    }
    </Breadcrumbs>
  }
  </Box>
  {app.navFamily && app.navFamily.length>0 && <Divider></Divider>}
  </>
  )
}
export default NavigationBar;