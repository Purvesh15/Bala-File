import React, {useEffect, useState} from 'react';
import { useNavigate } from 'react-router-dom';
import {Badge,AppBar,Toolbar ,InputBase,Paper,Menu,MenuItem,Divider,MenuList, Button} from '@mui/material';
import AccountCircle from '@mui/icons-material/AccountCircle';
import SearchTwoToneIcon from '@mui/icons-material/SearchTwoTone';
import CountryDialogBox from '../../components/header/countryDialogBox';
import './header.css';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { useSelector } from 'react-redux';
import { useDispatch } from 'react-redux';
import { setAppLanguage, setCurrentFamily, setNavFamily, setSalesArea } from '../../actions/appAction';
import MenuBar from '../../components/header/menubar';
import FilterResult from '../../components/header/filterResult';
import ProductFamilyTKE from '../../assets/json/productFamily.json';
const Header =()=>{
    const navigate=useNavigate();
    const dispatch=useDispatch();
    const [open, setMenu] = useState(false);
    const app=useSelector(state=>state.app);
    const [anchorEl, setAnchorEl] = useState(null);
    const [openLanguageDialog, setLanguageDialog] = useState(false);
    const [language, setLanguage] = useState("English");
    const [languageArray,setAllLanguage]=useState([]);
    const [settingsArray,setSettingsArray]=useState([]);
    const [filterResults,setFilterResult]=useState([]);
    const [searchResults,setSearchResult]=useState([]);
    const t=useSelector(state=>state.app.translation)
    const [openSearchMenu,setSearchMenu]=useState(false);
    const allFamilies=[];
    const array=[
        {
            name:"Language",
            label:"Language",
            options:[
                {name:"English" ,value:"en"},
                {name:"Germany" ,value:"de"},
                {name:"Spanish" ,value:"es"} 
            ]
        },
        {
            name:"Sales Area",
            label:"Sales Area",
            options:[
                {name:"United Kingdom" ,value:"UK",currency:"£"},
                {name:"United States" ,value:"US",currency:"$"},
                {name:"India" ,value:"India",currency:"₹"}
            ]
        }
    ]
    useEffect(() => {
        if( languageArray.length === 0 ){
            const languages=[
                {name:"English" ,value:"en"},
                {name:"Germany" ,value:"de"},
                {name:"Spanish" ,value:"es"}
            ]
            const salesArea=[
                {name:"United Kingdom" ,value:"UK",currency:"£"},
                {name:"United States" ,value:"US",currency:"$"},
                {name:"India" ,value:"India",currency:"₹"}
            ]
            setAllLanguage(languages);
            setSettingsArray(array)
        }
        getFamilies(ProductFamilyTKE);
        setFilterResult(allFamilies);
        window.addEventListener('click', function(event){   
            if (event&& document.getElementById('headerSearch')?.contains(event.target)){
              console.log("dsadsa")
            }  
            else{
                setSearchMenu(false);
            }
        });
    },[]);
    const getFamilies=(data)=>{
        data.children.forEach((family)=>{
            if(!allFamilies.includes(family.name)){
                allFamilies.push(family.name);
            }
            if(family.children&& family.children.length>0){
               getFamilies(family);
            }
        });
    }
    const handleClose=()=>{
        setAnchorEl(null);
        setMenu(!open);
    }
    const handleClickMenu=(e)=>{
        setAnchorEl(e.currentTarget);
        setMenu(!open);
    }
    const handleClickLanguage=(e)=>{
        setLanguageDialog(true);
    }
    const handleCloseLanguageDialog=()=>{
        setLanguageDialog(false);
    }
    const handleChangeLanguage=(e,item)=>{
        if(item.name=="Language"){
            setLanguage(e.target.value);
            dispatch(setAppLanguage(e.target.value))
        }
        else{
            var currentSalesArea=null;
            item.options.map((option)=>{
                if(option.value==e.target.value){
                    currentSalesArea=option;
                }
            })
            //setSalesArea(e.target.value)
            dispatch(setSalesArea(currentSalesArea))
        }
        setLanguageDialog(false);
      
    }
    const handleClickCart=()=>{
        dispatch(setNavFamily([]));
        navigate('/cart')

    }
    const handleChangeSearch=(e)=>{
       var data=[];
       filterResults.forEach((item)=>{
            if(!data.includes(item) && item.toLowerCase().includes(e.currentTarget.value.toLowerCase())){
                data.push(item);
            }
       });
       setSearchResult(data);
    }

    const handleSearchFocus=()=>{
        setSearchMenu(true);
    }

    const handleSearch=(e)=>{
        dispatch(setCurrentFamily(e.currentTarget.innerText));
        setSearchMenu(false);

    }
   
    return(
     <>
      <AppBar className="header">
       <Toolbar sx={{minHeight:"45px !important"}}>
       <img className='header-logo' src="https://companieslogo.com/img/orig/CTSH_BIG.D-6e2ffe6b.png?t=1652276339"/>
       <div>
            <Paper
                id="headerSearch"
                component="form"
                sx={{flexBasis:"35%", display: 'flex', alignItems: 'center', width: 270 ,height:25}}
                >
                <SearchTwoToneIcon className='searchIcon'></SearchTwoToneIcon>
                <InputBase
                    sx={{fontSize:"12px !important", ml: 1, flex: 1 }}
                    placeholder={t?.header?.search}
                    inputProps={{ 'aria-label': 'search' ,color:"darkBlue"}}
                    onChange={(e)=>handleChangeSearch(e)}
                    onFocus={(e)=>handleSearchFocus(e)}
                />
            </Paper>
            {openSearchMenu && searchResults.length>0 && <FilterResult searchResults={searchResults} handleSearch={handleSearch} ></FilterResult>}
       </div>
        <div className='headerName' onClick={()=>navigate('/')}> {t?.header?.headerName}</div>  
        <div  className="userProfile">
        <div className='header-cartbutton'>
            <Badge badgeContent={app.cartItems.length} color="secondary">
               <ShoppingCartIcon  onClick={()=>handleClickCart()}></ShoppingCartIcon>
            </Badge>
        </div>  
        <div id="profile" onClick={(e)=>handleClickMenu(e)} className='header-profile'>
            <AccountCircle></AccountCircle>
        </div>
        </div>
        </Toolbar>
        </AppBar>
        {open&&
            <MenuBar language={language} handleClickLanguage={handleClickLanguage}></MenuBar>
        }
        {openLanguageDialog && 
            <CountryDialogBox
                open={openLanguageDialog}
                handleCloseLanguageDialog={handleCloseLanguageDialog}
                languageArray={languageArray}
                currentLanguage={language}
                handleChangeLanguage={handleChangeLanguage}
                settingsArray={settingsArray}
            ></CountryDialogBox>
        }
     </>
    )
}
export default Header;