import React, {useState} from 'react';
import {AppBar} from '@mui/material';
import './footer.css';
const Footer=()=>{
    return(
        <>
          <AppBar className="footer">
            <div className='footerItem'>
                <a className='paddingFooterList'>Version 1.0.3</a>
                <a className='paddingFooterList'>Privacy Notice</a>
                <a className='paddingFooterList'>About Us</a>
            </div>
          </AppBar>
          
        </>
    )
}
export default Footer;