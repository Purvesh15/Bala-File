import React, {useEffect, useState} from 'react';
import productSelector from '../../assets/json/productSelector.json';
import NavigationBar from '../navigation/navigationBar';
import { changeNavigation, setAccessoryConfigurations, setCurrentFamily } from '../../actions/appAction';
import {useDispatch,useSelector} from 'react-redux';
import AccessoryList from '../../components/accessory/accessoryList';
import AccessorySelector from '../../components/accessory/accessorySelector';
import AccessorySelectorData from '../../assets/json/accessorySelector.json';
import AccessoryData from '../../assets/json/accessory.json'
import {appBarClasses, Button} from '@mui/material'
import { CandlestickChart } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import {addToCartItem} from '../../actions/appAction'
import Message from '../../components/common/message';
import './accessory.css'
import AccessoryProduct from '../../components/accessory/accessoryProduct';
import { v4 as uuidv4, v4 }  from 'uuid';

const Accessory =(props)=>{
    const dispatch=useDispatch();
    const navigate=useNavigate();
    const [selector,setSelector]=useState([]);
    const [isGridView,setView]=useState(true);
    const [isProductPage,setProductPage]=useState(true);
    const [accessories,setAccessories]=useState([]);
    const [accessorySelector,setAccessorySelector]=useState([]);
    const [isOpen ,setOpen]=useState(false);
    const [cartMessage,setMessage] =useState("");
    const [accTabs,setAccTab]=useState([])
    const app=useSelector(state=>state.app);
    const [tabIndex,setTab]=useState(0);
    const [totalPrice,setTotalPrice]=useState(0)
    const salesArea=useSelector(state=>state.app.salesArea);

    useEffect(()=>{
        setSelector(productSelector);
        var tabs=[];
        AccessorySelectorData.forEach((selector)=>{
            tabs.push(selector.name);
        })
        setAccessorySelector(AccessorySelectorData);
        dispatch(setAccessoryConfigurations(AccessorySelectorData));
        setAccessories([]);
        setAccTab(tabs);
        setTotalPrice(props.currentProduct.price)
    },[]);
    const handleClickConfigure=(product)=>{
        setProductPage(false);
    }
    const handleChangeTab=(index)=>{
        setTab(index);
        setAccessories([]);
    }
    const addToCart=(accessory)=>{
        var newCartItems=JSON.parse(JSON.stringify(app.cartItems));
        accessory.guid=v4();
        newCartItems.forEach((cartItem)=>{
          if(cartItem.id ==props.currentProduct.id){
            if(cartItem.children){
                //accessories.map((accessory)=>{
                    cartItem.children.push(accessory);
                //});
            }
            else{
               cartItem.children=[];
               //accessories.map((accessory)=>{
                cartItem.children.push(accessory);
               //});
            }
          }
        });
        //newCartItems.push(product);
        dispatch(addToCartItem(newCartItems));
        setOpen(true);
        setMessage("  Accessories are added to the Cart");
    }
    const handleChangeDropDown=(event,item,index)=>{       
        var accSelectorData=[...accessorySelector];
        var count=0;
        accSelectorData[tabIndex].configuration.forEach(data => {
            if(data.name==item.name && event!=null ){
                data.selectedValue=event.target.value;
            }
            else if(data.name==item.name && event==null ){
                data.selectedValue="";
            }
            if(data.selectedValue && data.selectedValue!=""){
               count++;
            }
        });
        var filterAccData=[];
        AccessoryData[tabIndex].products.forEach((accData,index)=>{
            if(count>index){
                filterAccData.push(accData);
            }
        });
        setAccessories(filterAccData);
        setAccessorySelector(accSelectorData);
        dispatch(setAccessoryConfigurations(accSelectorData));

    }
    const resetAll=()=>{
        var accSelectorData=[...accessorySelector];
        accSelectorData[tabIndex].configuration.forEach(data => {
            //if(data.name==item.name && event!=null ){
                data.selectedValue="";
            //}
          
        });        
        setAccessories([]);
        setAccessorySelector(accSelectorData);
    }    
    const changeQuantity=(e,currentAccessory)=>{
        var newAccessories=[...accessories];
        
            newAccessories.forEach((acc)=>{
                if(acc.image===currentAccessory.image){
                    if(e.target.value!=""){
                        acc.orderQuantity=parseInt(e.target.value );
                        if(acc.unitPrice==undefined){
                            acc.unitPrice= acc.Price
                            acc.Price= (acc.Price*parseInt(e.target.value )).toFixed(2);
                        }
                        else{
                            acc.Price= (acc.unitPrice*parseInt(e.target.value )).toFixed(2);
                        }
                    }
                    else{
                        acc.orderQuantity=0;
                        if(acc.unitPrice==undefined){
                            acc.unitPrice= acc.Price
                        }
                        acc.Price=0;
                    }
                  
                }
              
            });
        
        
        setAccessories(newAccessories);
        var newTotalPrice=totalPrice;
        if(newAccessories.length>0){
            var totalAccessoryPrice=0;
            newAccessories.forEach(accessory => {
                totalAccessoryPrice+=parseInt(accessory.Price);
            });
            totalAccessoryPrice=totalAccessoryPrice.toFixed(2);
        }
        newTotalPrice=(parseInt(totalAccessoryPrice)+props.currentProduct.price).toFixed(2);
        setTotalPrice(newTotalPrice);

    }
    return (
        <>
            <Message open={isOpen} message={cartMessage} ></Message>
            <div className='navbar'><NavigationBar></NavigationBar></div>
            <div className='acc-margin'>
                <div>
                    <div className='flex'>
                        <a className='accessoryLabel'>{props.currentProduct.description}</a>
                        <div className='accessoryPrice-content'>
                            <div className='accessoryPrice-label'>
                                Total Price
                            </div>
                            <div className='accessoryPrice-label'>
                             {salesArea.currency+" "+totalPrice }
                            </div>
                         </div>
                    </div>
                </div>
                <div className='acc-content' >  
                    {accTabs.length>0 && <AccessorySelector resetAll={resetAll} handleChangeTab={handleChangeTab} tabIndex={tabIndex} handleChangeDropDown={handleChangeDropDown} accTab={accTabs} accessorySelector={accessorySelector}></AccessorySelector> }
                    <div className='acc-list-content' >
                        <AccessoryProduct changeQuantity={changeQuantity} addToCart={addToCart} accessories={accessories}></AccessoryProduct>
                    </div>
                </div>
            </div>
        </>
    )
}
export default Accessory;