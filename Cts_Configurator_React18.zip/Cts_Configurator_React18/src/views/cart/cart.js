import { Button } from '@mui/material';
import React, { useEffect,useState } from 'react'
import { useSelector } from 'react-redux';
import CartTable from '../../components/cart/cartTable';
import ExportToExcel from '../../components/cart/exportExcel';
import ExportToPdf from '../../components/cart/exportPdf';
import Report from '../../components/cart/report';
import SingleReport from '../../components/cart/singleReport';
import './cart.css'
const Cart =()=>{
    const [totalPrice,setTotalPrice]=useState(0)
    const salesArea=useSelector(state=>state.app.salesArea);
    const cartItems=useSelector(state=>state.app.cartItems);

    useEffect(()=>{
        getTotalPrice();
    },[])
    useEffect(()=>{
        getTotalPrice();
    },[cartItems])
    const getTotalPrice=()=>{
        var updateTotalPrice=0;
        cartItems.forEach(cartItem => {
            updateTotalPrice+=(parseInt(cartItem.price)*cartItem.stock).toFixed(2);
            if(cartItem.children && cartItem.children.length>0){
                cartItem.children.forEach((children)=>{
                    updateTotalPrice+=(parseInt(children.Price)*cartItem.orderQuantity).toFixed(2);
                })
            }
        });
        setTotalPrice(updateTotalPrice)
    }
    return (
        <>
         <div className='cart-table'>
            <div style={{flexBasis:"85%"}}>Product Cart</div>
            <div style={{flexBasis:"15%"}}>{"Total Price: "+ salesArea.currency +" "+totalPrice}</div>
         </div>
         <div className='cart-main'>
            <CartTable></CartTable>
         </div>
         <div style={{padding:"6px",display:"flex"}}>
                <ExportToExcel></ExportToExcel>
                <ExportToPdf></ExportToPdf>
                <SingleReport></SingleReport>
         </div>
        </>
    )
}
export default Cart;