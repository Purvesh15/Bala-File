import React, { useState } from 'react'
import NavigationBar from '../navigation/navigationBar';
import ProductFamily from '../productFamily/productFamily';
import './home.css'
import {Card, Grid, CardActionArea, CardContent, Typography, CardMedia, Divider } from '@mui/material'
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { setCurrentFamily } from '../../actions/appAction';
import QuoteConfiguration from '../quoteConfiguration/quoteConfiguration';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import ArrowDropUpIcon from '@mui/icons-material/ArrowDropUp';
const Home =()=>{
    const navigate=useNavigate();
    const dispatch=useDispatch();
    const t=useSelector(state=>state.app.translation)
    const list=[{description:" Product catalog option to configure and pricing the Electronics product.",label:t?.home?.productCatalog},{description:"Quote tool is to configure the products by user selection",label:t?.home?.quoteTool}]
    const[openQuoteOption,setQuoteOption]=useState(false)
    const handleClickCard=(item,index)=>{
      if(index==0){
        navigate('/productFamily')
      }
      else{
        setQuoteOption(!openQuoteOption);
        window.scrollTo(0, 1000);
      }

    }
    return (
        <div className='navbar'>
          <div className='home-content'>
            {list.map((item,index)=>{
                    return(
                    <>
                      {/* <div> 
                        <Typography sx={{fontSize:"12px"}} align="center" gutterBottom variant="body2" component="div" >
                           {item.description}
                        </Typography>
                      </div> */}
                      <Grid sx={{m:1}} item xs={2.4} onClick={()=> handleClickCard(item,index)} >
                        <Card sx={{width :"20%",color:"white",background:"#000048",padding:"5px"}}>
                            <CardActionArea >
                                <CardContent>
                                    <Typography sx={{fontSize:"12px"}} align="center" gutterBottom variant="body2" component="div" >
                                      {item.label}
                                    </Typography>
                                </CardContent>
                                {index==1 && openQuoteOption && <ArrowDropDownIcon></ArrowDropDownIcon>}
                            </CardActionArea>
                        </Card>
                      </Grid>
                    </>
                     )

                })
                
                }
                {openQuoteOption && <QuoteConfiguration></QuoteConfiguration>
                }
          </div>
          {/* <div className='productFamily'><ProductFamily ></ProductFamily></div>  */}
        </div>
    )

}
export default Home;