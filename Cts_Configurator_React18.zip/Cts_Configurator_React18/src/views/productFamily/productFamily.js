
import ProductTreeView from '../../components/productFamily/productTreeView'
import SearchBox from '../../components/productFamily/searchBox'
import GridViewIcon from '@mui/icons-material/GridView';
import AccountTreeIcon from '@mui/icons-material/AccountTree';
import React,{ useState } from 'react';
import './productFamily.css'
import NavigationBar from '../navigation/navigationBar';
const ProductFamily =()=>{
    const [isTreeView,setTreeView]=useState(false);
    const handleChangeTile=()=>{
        setTreeView(!isTreeView);
    }
    return (
        <>
        <div className='navbar'><NavigationBar></NavigationBar></div>
            <div className='familyHeight'>
                <div className='flex'>
                <a className='productFamilyLabel'>Product Families</a>
                </div>
            <div className='search'><SearchBox isTreeView={isTreeView}></SearchBox></div>
        </div>
        </>
    )

}
export default ProductFamily;