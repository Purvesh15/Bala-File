import React from "react";
import {Card, Grid, CardActionArea, CardContent, Typography, CardMedia, Divider, FormControl, OutlinedInput } from '@mui/material'
import Images from '../../assets/js/asset'
import { Box } from "@mui/system";
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';
import KeyboardDoubleArrowDownIcon from '@mui/icons-material/KeyboardDoubleArrowDown';
import KeyboardDoubleArrowUpIcon from '@mui/icons-material/KeyboardDoubleArrowUp';
import { useState } from "react";
import { useSelector } from "react-redux";

const QuoteProduct=(props)=>{
    const [isExpand,setExpand]=useState(true);
    const salesArea =useSelector(state=>state.app.salesArea)
    const clickCollapse=()=>{
        setExpand(!isExpand)
      }
return(

    <div style={{paddingTop:"5px"}}>
    <div style={{color:"white",cursor:"pointer",padding:"9px",background:"#3737c1",display:"flex"}} onClick={(e)=>clickCollapse()}>
            <div style={{flexBasis:"90%"}}>Products</div>
            <div style={{flexBasis:"10%"}}>
                {!isExpand && <KeyboardDoubleArrowDownIcon ></KeyboardDoubleArrowDownIcon>}
                {isExpand &&<KeyboardDoubleArrowUpIcon ></KeyboardDoubleArrowUpIcon>}
            </div>
        </div>
    {isExpand && <Grid container spacing={1} style={{ marginTop:"1px"}}> 
            {props.products.length>0 && 
                props.products.map((product)=>{
                   return(
                    <Grid item xs={2.4} style={{minWidth:"150px"}} >
                        <Card>
                            <CardActionArea >
                                <CardMedia
                                    component="img"
                                    height="140"
                                    image={Images[product.image]}
                                    sx={{objectFit:"contain"}}
                                />
                                <CardContent>
                                    {/* <Typography sx={{fontSize:"10px"}} align="center" gutterBottom variant="body2" component="div" >
                                      {product.title}
                                    </Typography> */}
                                    <Typography sx={{fontSize:"10px",height:"20px",overflow:"hidden",paddingBottom:"4px"}} align="center" variant="body2" color="text.secondary">
                                      {product.description}
                                    </Typography>
                                    <Typography sx={{fontSize:"10px",height:"20px",overflow:"hidden",paddingBottom:"4px"}} align="center" variant="body2" color="text.secondary">
                                      {product.processor}
                                    </Typography>
                                    <Typography sx={{fontSize:"10px",height:"20px",overflow:"hidden",paddingBottom:"4px"}} align="center" variant="body2" color="text.secondary">
                                      {product.displaySize}
                                    </Typography>
                                    <Typography sx={{fontSize:"10px",height:"20px",overflow:"hidden",paddingBottom:"4px"}} align="center" variant="body2" color="text.secondary">
                                      {product.os}
                                    </Typography>
                                    <Typography sx={{fontSize:"10px",height:"20px",overflow:"hidden",paddingBottom:"4px"}} align="center" variant="body2" color="text.secondary">
                                      {product.memory}
                                    </Typography>
                                    <Divider></Divider>
                                    <Box sx={{display:"flex",paddingTop:"10px"}}>
                                        <FormControl sx={{flexBasis:"30%",paddingTop:"6px"}}>
                                        <OutlinedInput  onChange={(e)=>props.changeProductQuantity(e,product)}  type="text" value={product.stock}  sx={{padding:"5px",fontSize:"12px",width:'60px !important',height:"20px",textAlignLast:"center !important"}}/>
                                        </FormControl>
                                        <AddShoppingCartIcon onClick={()=>props.addToCart(product)} sx={{color:"#2E308E",display:"flex",flexBasis:"40%",cursor:"pointer",textAlignLast:"center !important"}} ></AddShoppingCartIcon>
                                        <Typography sx={{alignSelf:"end",paddingTop:"6px",flexBasis:"50%",fontWeight:'bold',fontSize:"14px",color:"#2E308E"}} variant="body2" color="text.secondary">
                                        { salesArea.currency +" "+ product.price}
                                        </Typography>
                                    </Box>
                                </CardContent>
                            </CardActionArea>
                        </Card>
                    </Grid> )

                })
                }
                {props.products.length==0 && 
                  <div style={{padding:"15% 0% 0% 25%"}}>The selected configuration have no products.Please try another configurations</div>
                }
        </Grid> 
        }
    </div>
    
)
}

export default QuoteProduct;