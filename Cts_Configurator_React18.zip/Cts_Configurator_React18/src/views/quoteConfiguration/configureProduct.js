
import React, { useEffect, useRef, useState } from 'react'
import productSelector from '../../assets/json/laptopSelector.json'
import Images from '../../assets/js/asset' ;
import { Button, FormControlLabel, Radio } from '@mui/material';
import ClipLoader from "react-spinners/BeatLoader";
import { getHardDiskImage } from '../../components/quote/laptop/svgImage';
import SendIcon from '@mui/icons-material/Send';
import QuoteProduct from './quoteProduct';
import laptopProducts from '../../assets/json/laptopProduct.json'
import KeyboardDoubleArrowDownIcon from '@mui/icons-material/KeyboardDoubleArrowDown';
import KeyboardDoubleArrowUpIcon from '@mui/icons-material/KeyboardDoubleArrowUp';
import { useDispatch, useSelector } from 'react-redux';
import { addToCartItem } from '../../actions/appAction';
import { v4 as uuidv4, v4 }  from 'uuid';
import ConflictMessage from '../../components/quote/laptop/conflictMessage';
const ConfigureProduct =()=>{
    const dispatch=useDispatch();
    const [selector,setSelector]=useState([])
    const [loader,setLoading]=useState(false)
    const [showNext,setShowNext]=useState(false);
    const [products,setProducts]=useState([]);
    const [showProduct,setShowProduct]=useState(false);
    const [isExpand,setExpand]=useState(true);
    const [conflict,setConflict]=useState(null);
    const app=useSelector(state=>state.app);
    const messagesEndRef = useRef(null)
    const override = {
        display: "block",
        margin: "0 auto",
        borderColor: "red",
        textAlign:"center"
      };
    useEffect(()=>{
        //setSelector(productSelector);
        productSelector.forEach((variable,index)=>{
            if(index==0){
                variable.isShow=true;
            }
            else{
                variable.isShow=false;  
            }
        })
        setSelector(productSelector);
    },[])
    //const variables=["RAM Memory","Hard Drive Capacity","Screen Size"]
    const getImage =(data,type,variableName,valueName)=>{
        // const image = new Image();
        // image.src = Images[data];
        // this.setState({
        //   hasError: false
        // })
        // image.onerror = () => {
        //   this.setState({
        //     hasError: true
        //   })
        // }
        if(type && type=="svgfssgf" && variableName=="Hard Drive Size"){
            return getHardDiskImage(valueName);
        }
        else{
            return Images[data];
        }
    }
    const handleChangeOption=(e,currentVariable)=>{
        var newSelector=JSON.parse(JSON.stringify(selector));
        var changeIndex=0;
        var currentId="";
        var showCount=0;
        var showNextCount=0;
        newSelector.forEach((variable,index)=>{
            if(variable.name==currentVariable.name ){
                if(variable.selectedValue!="" && variable.name=="Brand"){
                    var conflictObj={
                        "open":true,
                        "isConflict":true,
                        "title":"Conflict Occur!",
                        "message":"The selected option conflicting the below Attributes.",
                        "conflictVariable":variable.name,
                        "conflictValue":e.currentTarget.value
                    }
                    setConflict(conflictObj);
                }
                else{
                    variable.selectedValue=e.currentTarget.value;
                    changeIndex=index
                }
              
               
            }
            if(variable.selectedValue!=""){
                showNextCount+=1;
            }
            if(index!=0 && ((changeIndex+1)==index)){
                variable.isShow=true;
                currentId="laptop-"+variable.name;
            }

            if(variable.isShow){
                showCount+=1;
            }
            
        })
        setLoading(true);
        setTimeout(()=>{
            setLoading(false)
            setSelector(newSelector);
           // messagesEndRef.current?.scrollINto({ behavior: "smooth" })
           if(newSelector.length==showCount ||showNextCount>3) {
                setShowNext(true);
                setShowProduct(false);
           }
        },500)
        // setTimeout(()=>{
        //     // const laptopContent = document.querySelector('laptopContent')
        //     // var id=document.getElementById(currentId); 
        //     // id.focus();  
        //     messagesEndRef.current?.scrollInto({ behavior: "smooth" })
        // },1000)
    }
    const clickNext=()=>{
       
        var newProducts=[];
        //selector.forEach(option=>{
            laptopProducts.forEach((product)=>{
                var brand=selector.find(x=>x.name=="Brand");
                var size=selector.find(x=>x.name=="Screen Size");
                var processor=selector.find(x=>x.name=="Processor");
                var harddisk=selector.find(x=>x.name=="Hard Drive Size");
                if(product.selector.Brand==brand.selectedValue&&product.selector['Screen Size']==size.selectedValue&&product.selector.Processor==processor.selectedValue&&
                    product.selector['Hard Drive Size']==harddisk.selectedValue){
                    newProducts.push(product);
                }
            })
        //})
        setExpand(false)
        setShowProduct(true);
        setProducts(newProducts);
    }
    const clickCollapse=()=>{
      setExpand(!isExpand);
    }
    const changeProductQuantity=(e,currentProduct)=>{
        var newProducts=[...products];
        newProducts.forEach((product)=>{
            if(product.image===currentProduct.image){
                if(e.target.value!=""){
                    product.stock=parseInt(e.target.value );
                    if(product.unitPrice==undefined){
                        product.unitPrice= product.price
                        product.price= (product.price*parseInt(e.target.value )).toFixed(2);
                    }
                    else{
                        product.price= (product.unitPrice*parseInt(e.target.value )).toFixed(2);
                    }
                }
                else{
                    product.stock=0;
                    if(product.unitPrice==undefined){
                        product.unitPrice= product.price
                    }
                    product.price=0;
                }
                
            }
            
        });
        setProducts(newProducts);
    }
    const clickReset=()=>{
        var conflictObj={
            "open":true,
            "isConflict":false,
            "title":"Reset Configuration",
            "message":"The selected option  and product will be clear"
        }
        setConflict(conflictObj);

    }
    const clickOK=()=>{
        productSelector.forEach((variable,index)=>{
            if(index==0){
                variable.isShow=true;
            }
            else{
                variable.isShow=false;  
            }
        })
        setShowNext(false);
        setShowProduct(false);
        setSelector(productSelector);
        setProducts([]);
    }
    const conflictOK=()=>{
        var newProductSelector=[...productSelector];
        newProductSelector.forEach((variable,index)=>{
            if(index==0){
                variable.isShow=true;
            }
            else{
                variable.isShow=false;  
            }
        })
        
        //var newSelector=JSON.parse(JSON.stringify(selector));
        var changeIndex=0;
        //var currentId="";
        var showCount=0;
        newProductSelector.forEach((variable,index)=>{
            if(variable.name==conflict.conflictVariable){
                    variable.selectedValue=conflict.conflictValue;
                    changeIndex=index
            }
            if(index!=0 && ((changeIndex+1)==index)){
                variable.isShow=true;
                //currentId="laptop-"+variable.name;
            }

            if(variable.isShow){
                showCount+=1;
            }
        })
        setLoading(true);
        setConflict(null);
        setTimeout(()=>{
            setLoading(false)
            setSelector(newProductSelector);
           // messagesEndRef.current?.scrollINto({ behavior: "smooth" })
           if(newProductSelector.length==showCount) {
            setShowNext(true);
           }
        },500)
    }
    const clickCancel=()=>{
        setConflict(null);
    }
    const addToCart=(product)=>{
        var newCartItems=[...app.cartItems];
        product.guid=v4();
        newCartItems.push(product);
        dispatch(addToCartItem(newCartItems));
        // setOpen(true);
        // setMessage(product.brand +"  Product Added to the Cart");
    }
   return(
    <div ref={messagesEndRef} id="laptopContent" style={{margin:"60px 0px 0px 10px"}}>
         <div style={{color:"white",cursor:"pointer",padding:"9px",background:"#3737c1",display:"flex"}}  onClick={(e)=>clickCollapse()}>
            <div style={{flexBasis:"90%"}}>Configure Options</div>
            <div style={{flexBasis:"10%"}}>
                {isExpand && <KeyboardDoubleArrowDownIcon></KeyboardDoubleArrowDownIcon>}
                {!isExpand &&<KeyboardDoubleArrowUpIcon ></KeyboardDoubleArrowUpIcon>}
            </div>
            
        </div>
        {isExpand && <div style={{textAlign:"end"}}>
            <Button style={{fontSize:"12px",color:"#000048"}} onClick={()=>clickReset()}>Reset</Button>
        </div>
        }
        {isExpand && <div style={{background:"white",padding:"10px"}}>
            {selector.map((variable)=>{
                return (variable.isShow && <>
                  <div  id={"laptop-"+variable.name}  style={{marginTop:"5px",padding:"15px",outline:"solid 1px rgb(180, 180, 189)"}}>
                    <div style={{color:"#000048",padding:"5px"}}>{variable.name}</div>
                    <div style={{display:"flex"}}>
                    {variable.options.map((option,index)=>{
                        return(
                            <>
                           <FormControlLabel
                            id={variable.name}
                            sx={{marginLeft:"1px",fontSize:"12px !important"}}
                            value={option.value}
                            control={
                                    <Radio onChange={(e)=>handleChangeOption(e,variable)}
                                    sx={{marginLeft:"1px",fontSize:"1rem !important"}} size="small" checked={option.value==variable.selectedValue}
                                    />
                                }
                            // label={option.value}
                            labelPlacement="Top"
                            />
                            <div style={{display:"block",textAlign:"center"}}>
                                {variable.imageType=="svg" &&
                                   getHardDiskImage(option.value)
                                }
                                { variable.imageType!="svg" &&
                                  <img style={{padding:"2px",width:"40%"}} src={getImage(option.image,variable.imageTypetype,variable.name,option.value)}></img>
                                }
                               <div style={{padding:"3px",fontSize:"12px"}}>{option.name}</div>
                            </div>
                        </>
                        )
                    })}
                    </div>
                  </div>
                </>)
            })}
            
            
         </div>}
         {showNext &&!showProduct&&
                <div style={{textAlign:"center",padding:"10px"}}>
                    <Button onClick={(e)=>clickNext(e)}variant="contained" endIcon={<SendIcon />}>
                      NEXT
                    </Button>
                </div>
            }
            
         {showProduct &&
              <QuoteProduct products={products} addToCart={addToCart}changeProductQuantity={changeProductQuantity}></QuoteProduct>
         }
         <ClipLoader
            color={"blue"}
            loading={loader}
            cssOverride={override}
            size={20}
            aria-label="Loading Spinner"
            data-testid="loader"
        />
        {conflict &&conflict.open && !conflict.isConflict &&
            <ConflictMessage handleClickCancel={clickCancel} handleClickOK={clickOK} conflict={conflict}></ConflictMessage>
        }
        {conflict &&conflict.open &&conflict.isConflict &&
            <ConflictMessage handleClickCancel={clickCancel} handleClickOK={conflictOK} conflict={conflict}></ConflictMessage>
        }
    </div>
   )
}
export default ConfigureProduct;