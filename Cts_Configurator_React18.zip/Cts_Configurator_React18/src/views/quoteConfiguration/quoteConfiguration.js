import React, { useState } from "react";
import {Card, CardActionArea, CardMedia, Grid} from "@mui/material";
import Laptop from '../../assets/images/Laptop.jpg'
import { useNavigate } from "react-router-dom";
import Images from '../../assets/js/asset';
const QuoteConfiguration=()=>{
    var navigate=useNavigate();
    const handleClickProduct=(item)=>{
        if(item=="laptop"){
            navigate('/quote');
        }
        else if(item=="cycle"){
            navigate('/quoteCycle');   
        }
        else if(item=="elevator"){
            navigate('/home');   
        }
    }
    return (
        <>
        <div style={{height:"180px",padding:"15px",background:"white", margin:"10px 10px 10px 10px",boxShadow:"0px 2px 2px rgb(0 0 0 / 20%)"}}>
            <div style={{fontSize:"12px"}}>Please select the categories to configure</div>
            <Grid container spacing={2} style={{marginTop:"1px",justifyContent:"center"}}> 
               <Grid item xs={2}  style={{minWidth:"200px",minHeight:"150px"}}  onClick={()=>handleClickProduct("laptop")}>
                    <Card >
                        <CardActionArea >
                            <CardMedia
                                component="img"
                                image={Images.laptopGroup}
                                sx={{width:"100%",height:"100%"}}
                            />
                            </CardActionArea>
                        </Card >
                    </Grid>        
                <Grid item xs={2}  style={{minWidth:"200px",minHeight:"200px"}}  onClick={()=>handleClickProduct("cycle")}>
                <Card >
                    <CardActionArea >
                        <CardMedia
                            component="img"
                            image={Images.bicycle}
                            sx={{width:"100%",height:"100%"}}
                        />
                        </CardActionArea>
                </Card >
                </Grid>      
                <Grid item xs={2}  style={{minWidth:"200px",minHeight:"200px"}}  onClick={()=>handleClickProduct("elevator")}>
                <Card >
                    <CardActionArea >
                        <CardMedia
                            component="img"
                            image={Images.bicycle}
                            sx={{width:"100%",height:"100%"}}
                        />
                        </CardActionArea>
                </Card >
                </Grid>        
            </Grid>
            
        </div>
            
        </>
    )
}
export default QuoteConfiguration;