import axios from 'axios';
import { useDispatch } from 'react-redux';
import { setProductFamily, updateUser } from '../actions/appAction';
    export async function getProducts(dispatch){
        await axios.get('https://localhost:7107/api/Product/get-products')
            .then(function (response) {
                // handle success
                console.log(response);
                dispatch(setProductFamily(response.data));
            })
            .catch(function (error) {
                // handle error
                console.log(error);
            })
            .finally(function () {
                // always executed
        });
    }
    
    export async function getUser(dispatch){
        await axios.get('https://localhost:7107/api/User')
            .then(function (response) {
                // handle success
                console.log(response);
                dispatch(updateUser(response.data));

            })
            .catch(function (error) {
                // handle error
                console.log(error);
            })
            .finally(function () {
                // always executed
        });
    }
