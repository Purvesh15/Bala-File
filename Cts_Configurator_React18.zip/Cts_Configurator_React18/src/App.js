import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router,Routes, Route, Link, Navigate } from 'react-router-dom';  
import './App.css';
import Home from './views/home/home'
import ProductTreeView from './components/productFamily/productTreeView';
import Configuration from './views/configuration/configuration';
import Header from './views/header/header';
import Footer from './views/header/footer';
import Cart from './views/cart/cart';
import {Provider, useDispatch, useSelector} from 'react-redux';
// import rootReducer from './reducers/rootReducer';
// import {createStore} from 'redux'
import { getProducts, getUser } from './api/userApi';
import { setProductFamily, setTranslation, updateUser } from './actions/appAction';
import ProductFamily from './views/productFamily/productFamily';
import LocalizedStrings from 'react-localization';
import language from './assets/json/language.json'
import QuoteConfiguration from './views/quoteConfiguration/quoteConfiguration';
import ConfigureProduct from './views/quoteConfiguration/configureProduct';
import CycleSvg from './components/quote/laptop/cycleSvg';

// import Navbar from './components/elevator/Navbar';
import HomePage from './views/elevator/HomePage';
import Elevator from './views/elevator/Elevator';
// import Footer from './components/elevator/Footer'
import { createTheme, ThemeProvider, StyledEngineProvider } from '@mui/material/styles';
import ElevatorCconfig from './views/elevator/ElevatorCconfig';
import EscalatorConfig from './views/elevator/EscalatorConfig'
import elevatorCart from './views/elevator/elevatorCart';
function App() {
  const dispatch=useDispatch();
  const translation=useSelector(state=>state.app.translation)
  const appLanguage=useSelector(state=>state.app.appLanguage)
  let strings = new LocalizedStrings(language);
  // const store = createStore(
  //   rootReducer,
  //   window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
  // );
  const theme = createTheme()
  const [burger, setburger] = useState(false)
    const [choosenElevator, setchoosenElevator] = useState("h200")
    const [elevatorCart , setelevatorCart] = useState()
    const [cart, setcart] = useState([])
    let savedUserDetails = localStorage.getItem('cart')
  useEffect(()=>{
    var prod=getProducts(dispatch);
    var user=getUser(dispatch);
    // dispatch(setProductFamily(prod))
    dispatch(setTranslation(strings))   
  },[])
  useEffect(()=>{
    strings.setLanguage(appLanguage);
    dispatch(setTranslation(strings))   
  },[appLanguage])
 
    useEffect(() => {
      if(savedUserDetails){
        setcart(JSON.parse(savedUserDetails))
      }
    },[])
    let savedchosenelev = localStorage.getItem('helev')
    useEffect(() => {
      if(savedchosenelev){
        setchoosenElevator(savedchosenelev)
      }
  },[])

  return (

    <Router>
       <div><Header></Header> </div>
      <div className="route-content">
        <Routes>  
          <Route exact path='/' element={< Home />}></Route>  
          <Route path='/productFamily' element={<ProductFamily/>}></Route>  
          <Route path='/configure' element={<Configuration />}></Route>  
          {/* <Route path='/cart' element={< Cart />}></Route> */}
          <Route path='/quote' element={<ConfigureProduct/>}></Route>
          <Route path='/quoteCycle' element={<CycleSvg/>}></Route>
          <Route path="/home" element={<HomePage setchoosenElevator={setchoosenElevator} choosenElevator={choosenElevator} burger={burger} setburger={setburger}/>} />
          {/* <Route path="/elevatorConfig" element={<Navigate to="/home" replace />} /> */}
          <Route path="/home/elevator" element={<Elevator  setchoosenElevator={setchoosenElevator}   choosenElevator={choosenElevator} />} />
          <Route path={`/home/elevator/elevator-${choosenElevator}`} element={<ElevatorCconfig cart={cart} setcart={setcart} elevatorCart={elevatorCart}  setelevatorCart={setelevatorCart}  setchoosenElevator={setchoosenElevator} choosenElevator={choosenElevator} />} />

          <Route path="/home/escalator-config" element={<EscalatorConfig cart={cart} setcart={setcart}  />} />
          <Route path="/elevatorCart" element={<Cart   cart={elevatorCart} setcart={setcart} />}/>
        </Routes> 
      </div> 
      <div>
        <Footer>

        </Footer>
      </div>
    </Router>
  );
}

export default App;
