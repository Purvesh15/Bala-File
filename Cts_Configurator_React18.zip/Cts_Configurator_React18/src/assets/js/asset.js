import dell_Logo from '../images/dell_logo.png'
import hp_Logo from '../images/hp_logo.png'
import asus_Logo from '../images/asus_logo.png'
import apple_Logo from '../images/apple_Logo.jpg'
import laptopGroup from '../images/laptops/laptopGroup.png'
import size_11 from '../images/size_11.png'
import size_14 from '../images/size_14.png'
import size_15 from '../images/size_15.png'
import size_17 from '../images/size_17.png'

import processor_i5 from '../images/Processor_i5.png'
import processor_i7 from '../images/Processor_i7.png'
import processor_i9 from '../images/Processor_i9.png'
import processor_amd_5 from '../images/Processor_amd_5.png'
import processor_amd_7 from '../images/Processor_amd_7.png'

import bicycle from '../images/bicycle.png'


import apple1 from '../images/laptops/Apple1.png'
import apple2 from '../images/laptops/Apple2.png'
import apple3 from '../images/laptops/Apple3.png'
import apple4 from '../images/laptops/Apple4.png'
import asus1 from '../images/laptops/Asus1.png'
import asus2 from '../images/laptops/Asus2.png'
import asus3 from '../images/laptops/Asus3.png'
import asus4 from '../images/laptops/Asus4.png'
import CTS_Logo from '../images/report/CTS_Logo.png';
import cover_Image from '../images/report/cover_Image.jpg';


const Images={
    bicycle:bicycle,
    dellLogo:dell_Logo,
    hpLogo:hp_Logo,
    asusLogo:asus_Logo,
    appleLogo:apple_Logo,
    size11:size_11,
    size14:size_14,
    size15:size_15,
    size17:size_17,
    intelcore5:processor_i5,
    intelcore7:processor_i7,
    intelcore9:processor_i9,
    amd5:processor_amd_5,
    amd7:processor_amd_7,
    apple1:apple1,
    apple2:apple2,
    apple3:apple3,
    apple4:apple4,
    asus1:asus1,
    asus2:asus2,
    asus3:asus3,
    asus4:asus4,
    laptopGroup:laptopGroup,
    CTSLogo:CTS_Logo,
    coverImage:cover_Image

}


export default Images;