import { useDispatch } from 'react-redux'


export const updateUser = (userDetails) => {
    return {
        type: 'UPDATE_USER',
        userDetails: userDetails
    }
}
export const changeNavigation = (currenPage) => {
    return {
        type: 'CHANGE_NAVIGATION',
        currenPage: currenPage
    }
    
}
export const setNavFamily = (navFamily) => {
    return {
        type: 'SET_NAV_FAMILY',
        navFamily: navFamily
    }
    
}
export const setCurrentFamily = (name) => {
    return {
        type: 'SET_CURRENT_FAMILY',
        currentFamily: name
    }
}
export const addToCartItem = (cartItems) => {
    return {
        type: 'ADD_CART_ITEM',
        cartItems: cartItems
    }
}
export const setProductFamily = (productFamilies) => {
    return {
        type: 'SET_PRODUCT_FAMILY',
        productFamilies: productFamilies
    }
}
export const setProductInfo = (productInfo) => {
    return {
        type: 'SET_PRODUCT_INFO',
        productInfo: productInfo
    }
}
export const setTranslation = (translation) => {
    return {
        type: 'SET_TRANSLATION',
        translation: translation
    }
}
export const setAppLanguage = (appLanguage) => {
    return {
        type: 'SET_APP_LANGUAGE',
        appLanguage: appLanguage
    }
}
export const setSalesArea = (salesArea) => {
    return {
        type: 'SET_SALES_AREA',
        salesArea: salesArea
    }
}
export const setProductConfigurations = (productConfigurations) => {
    return {
        type: 'SET_PRODUCT_CONFIGURATION',
        productConfigurations: productConfigurations
    }
}
export const setAccessoryConfigurations = (accessoryConfigurations) => {
    return {
        type: 'SET_ACCESSORY_CONFIGURATION',
        accessoryConfigurations: accessoryConfigurations
    }
}



